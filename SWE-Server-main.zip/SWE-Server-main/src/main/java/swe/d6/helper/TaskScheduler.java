package swe.d6.helper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import swe.d6.entries.QuestionEntry;
import swe.d6.objects.Questions;
import swe.d6.util.SQLUtil;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.time.LocalDateTime;
import java.time.temporal.WeekFields;
import java.util.concurrent.TimeUnit;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class TaskScheduler {
    private static final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

    private static final Logger LOGGER = LoggerFactory.getLogger(TaskScheduler.class);

    public static void init() throws Exception {
        String date = SQLUtil.queryPreparedStatement("SELECT * FROM date LIMIT 1", null, resultSet -> {
            if (resultSet.next()) return resultSet.getString("date");
            return null;
        });
        if (date == null) {
            SQLUtil.executePreparedStatement("INSERT INTO date(date) VALUES (CURRENT_DATE)", null);
            dailyTask();
            weeklyTask();
            monthlyTasks();
        } else {
            LocalDate localDate = LocalDate.parse(date);
            LocalDate today = LocalDate.now();
            if (!localDate.equals(today)) dailyTask();
            if (localDate.get(WeekFields.ISO.weekOfYear()) != today.get(WeekFields.ISO.weekOfYear())) weeklyTask();
            if (localDate.getMonth() != today.getMonth()) monthlyTasks();
        }
        scheduleDailyTasks();
        scheduleWeeklyTasks();
        scheduleMonthlyTasks();
    }

    public static void scheduleRepeatingTask(Runnable task, long initialDelay, long period, TimeUnit timeUnit) {
        // Schedule the task with the specified initial delay, period, and time unit
        scheduler.scheduleAtFixedRate(task, initialDelay, period, timeUnit);
    }

    public static void scheduleTask(Runnable task, long initialDelay, TimeUnit timeUnit) {
        // Schedule the task with the specified initial delay, and time unit
        scheduler.schedule(task, initialDelay, timeUnit);
    }

    public static void shutdown() {
        // Shutdown the scheduler when it's no longer needed
        scheduler.shutdown();
    }

    public static void scheduleDailyTasks() {
        scheduleTask(() -> {
            dailyTask();
            scheduleDailyTasks();
        }, Duration.between(LocalDateTime.now(), LocalDate.now().plusDays(1).atStartOfDay()).toNanos(), TimeUnit.NANOSECONDS);
    }

    public static void dailyTask(){
        LOGGER.info("Running daily tasks");
        try {
            SQLUtil.executeBatchSQL(null,
                    new SQLUtil.SQLObject("DELETE FROM sessions WHERE date(expiration_date) <= date('now');", null, false),
                    new SQLUtil.SQLObject("DELETE FROM daily_scores", null, false),
                    new SQLUtil.SQLObject("UPDATE date SET date = CURRENT_DATE WHERE _ROWID_=1", null, false)
            );
            Questions.setDailyGame();
        } catch (Exception e) {
            LOGGER.error("Error in daily task", e.getCause());
        }
    }

    public static void scheduleWeeklyTasks() {
        scheduleTask(() -> {
            weeklyTask();
            scheduleWeeklyTasks();
        }, Duration.between(LocalDateTime.now(), LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.MONDAY)).atStartOfDay()).toNanos(), TimeUnit.NANOSECONDS);
    }

    public static void weeklyTask(){
        LOGGER.info("Running weekly tasks");
        try {
            SQLUtil.executePreparedStatement("DELETE FROM weekly_scores", null);
            Questions.setWeeklyGame();
        } catch (Exception e) {
            LOGGER.error("Error in weekly task", e.getCause());
        }
    }

    public static void scheduleMonthlyTasks() {
        scheduleTask(() -> {
            monthlyTasks();
            scheduleMonthlyTasks();
        }, Duration.between(LocalDateTime.now(), LocalDate.now().with(TemporalAdjusters.firstDayOfNextMonth()).atStartOfDay()).toNanos(), TimeUnit.NANOSECONDS);
    }

    public static void monthlyTasks(){
        LOGGER.info("Running monthly tasks");
        try {
            SQLUtil.executeBatchSQL(null,
                    new SQLUtil.SQLObject("DELETE FROM placements;", null, false),
                    new SQLUtil.SQLObject("INSERT INTO placements SELECT user_id, row_number() OVER (ORDER BY score DESC, user_id ASC) as rank FROM monthly_scores;", null, false),
                    new SQLUtil.SQLObject("DELETE FROM monthly_scores;", null, false),
                    new SQLUtil.SQLObject("UPDATE users SET first_place = first_place + CASE WHEN id =(SELECT user_id FROM placements WHERE rank = 1 LIMIT 1) THEN 1 ELSE 0 END, second_place = second_place + CASE WHEN id = (SELECT user_id FROM placements WHERE rank = 2 LIMIT 1) THEN 1 ELSE 0 END, third_place = third_place + CASE WHEN id = (SELECT user_id FROM placements WHERE rank = 3 LIMIT 1) THEN 1 ELSE 0 END;", null, false)
            );
        } catch (Exception e) {
            LOGGER.error("Error in monthly task", e.getCause());
        }
    }
}