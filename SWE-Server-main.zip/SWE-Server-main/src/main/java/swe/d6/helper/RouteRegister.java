package swe.d6.helper;

import io.github.classgraph.*;
import jakarta.validation.constraints.NotNull;
import spark.Spark;
import spark.staticfiles.MimeType;
import swe.d6.interfaces.RouteMapping;
import swe.d6.util.statics.RequestMethods;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import spark.Route;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static spark.Spark.*;

public class RouteRegister {
    public static void registerRoutes(@NotNull String packageName) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        String pkg = packageName;
        String routeAnnotation = "swe.d6.interfaces.RouteMapping";
        try (ScanResult scanResult =
                     new ClassGraph()
                             .enableClassInfo()
                             .enableAnnotationInfo()
                             .acceptPackages(pkg)
                             .scan()) {
            for (ClassInfo routeClassInfo : scanResult.getClassesWithAnnotation(routeAnnotation)) {
                Object classInstance = routeClassInfo.loadClass().getDeclaredConstructor().newInstance();
                if (classInstance instanceof Route route){
                    AnnotationInfo routeAnnotationInfo = routeClassInfo.getAnnotationInfo(routeAnnotation);
                    List<AnnotationParameterValue> routeParamVals = routeAnnotationInfo.getParameterValues();
                    String name = (String) routeParamVals.get(1).getValue();
                    if (name.isEmpty()) name = Character.toLowerCase(routeClassInfo.getSimpleName().charAt(0)) + routeClassInfo.getSimpleName().substring(1);
                    String routePath = (String) routeParamVals.get(2).getValue();
                    if (routePath.isEmpty()) routePath = routeClassInfo.getPackageName().substring(packageName.length()).replace('.', '/') + "/" + name;
                    else routePath += "/" + name;
                    switch (((AnnotationEnumValue) routeParamVals.getFirst().getValue()).getValueName()) {
                        case "GET" -> get(routePath, route);
                        case "POST" -> post(routePath, route);
                        case "PUT" -> put(routePath, route);
                        case "DELETE" -> delete(routePath, route);
                    }
                }
            }
        }
    }
    public static void registerStaticFileRoute(String folderPath) throws IOException {
        try (ScanResult scanResult = new ClassGraph().acceptPaths(folderPath).scan()) {
            scanResult.getAllResources().forEachByteArrayThrowingIOException((Resource res, byte[] content) -> {
                int i = res.getPath().lastIndexOf(".");
                Route route;
                String fileContent = new String(content, StandardCharsets.UTF_8);
                String mimeType = MimeType.mappings.getOrDefault(i != -1 ? res.getPath().substring( i + 1) : "", ("application/" + (i != -1 ? res.getPath().substring( i + 1) : "*")));
                if (fileContent.startsWith("<!--admin-->")) {
                    content = fileContent.substring(12).getBytes(StandardCharsets.UTF_8);
                    route = new StaticFileAdmin(content,  mimeType);
                } else route = new StaticFile(content, mimeType);
                String path = res.getPath().replaceFirst(folderPath, "").replace(".html", "");
                get(path.equals("/index") ? "/" : path, route);
            });
        }
    }
}
