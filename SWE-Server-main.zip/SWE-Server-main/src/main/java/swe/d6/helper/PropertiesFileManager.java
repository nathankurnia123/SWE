package swe.d6.helper;

import java.io.*;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Properties;

public class PropertiesFileManager {
    public static Properties load(){
        try {
            return loadProperties("config.properties");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static Properties loadProperties(String filename) throws IOException {
        File file = new File(filename);
        if (file.createNewFile()) saveProperties(filename);
        Properties properties = new Properties();
        try (InputStream input = new FileInputStream(file)) {
            properties.load(input);
        }
        return properties;
    }

    private static void saveProperties(String filename) throws IOException {
        try (OutputStream output = new FileOutputStream(filename)) {
            Properties properties = new Properties();
            properties.setProperty("secretKey", generateRandomBase64(32));
            properties.store(output, null);
        }
    }

    private static String generateRandomBase64(int length) {
        byte[] bytes = generateRandomBytes(length);
        return Base64.getEncoder().encodeToString(bytes);
    }

    static byte[] generateRandomBytes(int length) {
        byte[] bytes = new byte[length];
        new SecureRandom().nextBytes(bytes);
        return bytes;
    }
}
