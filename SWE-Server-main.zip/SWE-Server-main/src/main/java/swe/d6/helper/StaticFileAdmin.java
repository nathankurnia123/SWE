package swe.d6.helper;

import spark.Request;
import spark.Response;
import swe.d6.routes.api.admin.BaseAdminRoute;

public class StaticFileAdmin extends BaseAdminRoute {
    private final byte[] content;
    private final String contentType;

    public StaticFileAdmin(byte[] content, String contentType) {
        this.content = content;
        this.contentType = contentType;
    }

    @Override
    public Object handler(Request request, Response response) throws Exception {
        response.type(contentType);
        return content;
    }
}
