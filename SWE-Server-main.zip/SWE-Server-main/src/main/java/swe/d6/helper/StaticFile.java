package swe.d6.helper;

import spark.Request;
import spark.Response;
import spark.Route;

public class StaticFile implements Route {
    private final byte[] content;
    private final String contentType;

    public StaticFile(byte[] content, String contentType) {
        this.content = content;
        this.contentType = contentType;
    }

    @Override
    public Object handle(Request request, Response response) throws Exception {
        response.type(contentType);
        return content;
    }
}
