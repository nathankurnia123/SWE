package swe.d6.helper;

import at.favre.lib.crypto.bcrypt.BCrypt;

public class Crypt {

    public static String hash(String toHash){
        return hash(toHash, BCrypt.MIN_COST);
    }

    public static String hash(String toHash, int cost){
        return BCrypt.withDefaults().hashToString(cost, toHash.toCharArray());
    }

    public static boolean verifyHash(String input, String hashed){
        return input != null && hashed != null && BCrypt.verifyer().verify(input.toCharArray(), hashed).verified;
    }
}
