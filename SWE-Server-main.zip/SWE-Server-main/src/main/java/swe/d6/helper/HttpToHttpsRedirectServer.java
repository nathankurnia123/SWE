package swe.d6.helper;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class HttpToHttpsRedirectServer {
    // Create a simple HTTP server on port 80
    private static final HttpServer SERVER;

    static {
        try {
            SERVER = HttpServer.create(new InetSocketAddress(80), 0);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void startServer() {
        // Create a context for handling requests
        SERVER.createContext("/", new RedirectHandler());

        // Create a default executor
        SERVER.setExecutor(null);

        // Start the server
        SERVER.start();
    }

    public static void stopServer(){
        SERVER.stop(10);
    }

    static class RedirectHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // Get the request URI
            String requestUri = exchange.getRequestURI().toString();

            // Build the HTTPS URL
            String httpsUrl = "https://" + exchange.getRequestHeaders().getFirst("Host") + requestUri;

            // Set up the redirect response
            exchange.getResponseHeaders().set("Location", httpsUrl);
            exchange.sendResponseHeaders(301, 0);

            // Send an empty response body
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(new byte[0]);
            }

            // Close the exchange
            exchange.close();
        }
    }
}