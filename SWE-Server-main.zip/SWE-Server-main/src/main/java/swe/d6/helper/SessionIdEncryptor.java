package swe.d6.helper;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import java.util.Base64;

import static swe.d6.util.statics.Statics.PROPERTIES;
public class SessionIdEncryptor {
    private static final String ALGORITHM = "AES";
    private static final SecretKeySpec SECRET_KEY_SPEC;

    static {
        byte[] temp = Base64.getDecoder().decode(PROPERTIES.getProperty("secretKey"));
        if (temp == null) throw new RuntimeException("could not find needed secretKey in properties file");
        SECRET_KEY_SPEC = new SecretKeySpec(temp, ALGORITHM);
    }

    public static String encryptSessionId(String sessionId) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, SECRET_KEY_SPEC);
        byte[] encryptedBytes = cipher.doFinal(sessionId.getBytes());
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    public static String decryptSessionId(String encryptedSessionId) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, SECRET_KEY_SPEC);
        byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedSessionId));
        return new String(decryptedBytes);
    }
}
