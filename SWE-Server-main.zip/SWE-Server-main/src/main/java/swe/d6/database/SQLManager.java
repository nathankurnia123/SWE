package swe.d6.database;

import swe.d6.util.FileReader;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SQLManager {
    public static void init() throws SQLException {
        String[] sqlQueries = FileReader.asString(SQLManager.class.getClassLoader().getResource("createTables.sql")).replace("\n", "").split(";");
        try (Connection connection = SQLiteConnectionPool.getConnection()) {
            for (String query : sqlQueries){
                try (PreparedStatement statement = connection.prepareStatement(query)) {
                    statement.execute();
                }
            }
        }
    }
}