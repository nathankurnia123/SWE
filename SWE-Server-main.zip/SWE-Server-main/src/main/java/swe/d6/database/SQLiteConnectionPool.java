package swe.d6.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import swe.d6.Main;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class SQLiteConnectionPool {
    private static final Logger LOGGER = LoggerFactory.getLogger(SQLiteConnectionPool.class);

    private static final HikariConfig config = new HikariConfig();
    private static final HikariDataSource dataSource;

    static {
        HikariDataSource dataSource1;
        File file = new File("wwm_questions.db");
        try {
            file.createNewFile();
            config.setDriverClassName("org.sqlite.JDBC");
            config.setJdbcUrl("jdbc:sqlite:"+ file.getPath());
            config.setConnectionTestQuery("SELECT 1");
            config.setMaxLifetime(60000);
            config.setMaximumPoolSize(1);
            dataSource1 = new HikariDataSource(config);
        } catch (IOException e) {
            LOGGER.error("could not create database file!");
            dataSource1 = null;
            Main.shutdown();
        }
        dataSource = dataSource1;
    }

    // Method to get a connection from the pool
    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    // Close the connection (return it to the pool) after usage
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Close the HikariCP data source when your application shuts down
    public static void closeDataSource() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }
}
