package swe.d6.objects;

import swe.d6.entries.LeaderboardEntry;
import swe.d6.util.SQLUtil;

import java.util.List;

public class Leaderboards {
    public static List<List<LeaderboardEntry>> getLeaderboardScoresApp(int userId) throws Exception {
        return SQLUtil.executeBatchSQL(LeaderboardEntry.class,
                new SQLUtil.SQLObject(
                        "WITH SELF AS (SELECT iif(s.score, ((SELECT COUNT(*) FROM daily_scores s2 WHERE s2.score > s.score) + 1), 0) AS rank, u.id AS user_id, u.first_name, u.discriminator, u.first_place, u.second_place, u.third_place, COALESCE(s.score, 0) AS daily_score FROM users u LEFT JOIN daily_scores s ON s.user_id = u.id WHERE u.id = ? LIMIT 1) SELECT * FROM SELF UNION SELECT * FROM (SELECT RANK() OVER ( ORDER BY score DESC) rank, u.id AS user_id, u.first_name, u.discriminator, u.first_place, u.second_place, u.third_place, s.score AS daily_score FROM daily_scores s LEFT JOIN users u ON s.user_id = u.id ORDER BY score DESC LIMIT 16 - (SELECT COUNT(*) FROM SELF)) ORDER BY daily_score DESC;",
                        preparedStatement -> preparedStatement.setInt(1, userId),
                        true//,
                        /*LeaderboardEntry.class*/),
                new SQLUtil.SQLObject(
                        "WITH SELF AS (SELECT iif(s.score, ((SELECT COUNT(*) FROM weekly_scores s2 WHERE s2.score > s.score) + 1), 0) AS rank, u.id AS user_id, u.first_name, u.discriminator, u.first_place, u.second_place, u.third_place, COALESCE(s.score, 0) AS weekly_score FROM users u LEFT JOIN weekly_scores s ON s.user_id = u.id WHERE u.id = ? LIMIT 1) SELECT * FROM SELF UNION SELECT * FROM (SELECT RANK() OVER ( ORDER BY score DESC) rank, u.id AS user_id, u.first_name, u.discriminator, u.first_place, u.second_place, u.third_place, s.score AS daily_score FROM weekly_scores s LEFT JOIN users u ON s.user_id = u.id ORDER BY score DESC LIMIT 16 - (SELECT COUNT(*) FROM SELF)) ORDER BY weekly_score DESC;",
                        preparedStatement -> preparedStatement.setInt(1, userId),
                        true//,
                        /*LeaderboardEntry.class*/),
                new SQLUtil.SQLObject(
                        "WITH SELF AS (SELECT iif(s.score, ((SELECT COUNT(*) FROM monthly_scores s2 WHERE s2.score > s.score) + 1), 0) AS rank, u.id AS user_id, u.first_name, u.discriminator, u.first_place, u.second_place, u.third_place, COALESCE(s.score, 0) AS monthly_score FROM users u LEFT JOIN monthly_scores s ON s.user_id = u.id WHERE u.id = ? LIMIT 1) SELECT * FROM SELF UNION SELECT * FROM (SELECT RANK() OVER ( ORDER BY score DESC) rank, u.id AS user_id, u.first_name, u.discriminator, u.first_place, u.second_place, u.third_place, s.score AS daily_score FROM monthly_scores s LEFT JOIN users u ON s.user_id = u.id ORDER BY score DESC LIMIT 16 - (SELECT COUNT(*) FROM SELF)) ORDER BY monthly_score DESC;",
                        preparedStatement -> preparedStatement.setInt(1, userId),
                        true//,
                        /*LeaderboardEntry.class*/)
        );
    }

    public static List<LeaderboardEntry> getLeaderboardScoresAdminInterface(String keyword, String page) throws Exception {
        int pageNum;
        try {
            pageNum = Integer.parseInt(page) - 1;
        } catch (NumberFormatException ignored) {
            pageNum = 0;
        }
        int finalPageNum = pageNum;
        String finalKeyword = keyword != null ? keyword.trim() : "";
        return SQLUtil.queryPreparedStatement("SELECT u.id AS user_id, u.first_name, u.discriminator, COALESCE(m.monthly_score, 0) AS monthly_score, COALESCE(w.weekly_score, 0) AS weekly_score, COALESCE(d.daily_score, 0) AS daily_score FROM users u LEFT JOIN( SELECT user_id, score AS monthly_score FROM monthly_scores ORDER BY score DESC) m ON u.id = m.user_id LEFT JOIN ( SELECT user_id, score AS weekly_score FROM weekly_scores ORDER BY score DESC ) w ON u.id = w.user_id LEFT JOIN ( SELECT user_id, score AS daily_score FROM daily_scores ORDER BY score DESC ) d ON u.id = d.user_id WHERE (first_name ||'#'||discriminator) LIKE ? OR id LIKE ? ORDER BY monthly_score DESC, weekly_score DESC, daily_score DESC LIMIT 20 OFFSET 20*?;",
                LeaderboardEntry.class, preparedStatement -> {
                    preparedStatement.setString(1, '%' + finalKeyword + '%');
                    preparedStatement.setString(2, '%' + finalKeyword + '%');
                    preparedStatement.setInt(3, finalPageNum);
                });
    }

    public static void resetUserScores(int userId) throws Exception {
        SQLUtil.executeBatchSQL(null,
                new SQLUtil.SQLObject("DELETE FROM daily_scores WHERE user_id = ?", preparedStatement -> preparedStatement.setInt(1, userId), false),
                new SQLUtil.SQLObject("DELETE FROM weekly_scores WHERE user_id = ?", preparedStatement -> preparedStatement.setInt(1, userId), false),
                new SQLUtil.SQLObject("DELETE FROM monthly_scores WHERE user_id = ?", preparedStatement -> preparedStatement.setInt(1, userId), false)
        );
    }
}
