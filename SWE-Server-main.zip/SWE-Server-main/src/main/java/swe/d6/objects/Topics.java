package swe.d6.objects;

import swe.d6.entries.TopicEntry;
import swe.d6.util.SQLUtil;

import java.lang.reflect.Field;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class Topics {
    private static final ConcurrentHashMap<Integer, TopicEntry> TOPICS = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<Integer, TopicEntry> TRAINING_TOPICS = new ConcurrentHashMap<>();

    private static final Field NUMBER_OF_QUESTIONS;

    /*initializes each topic with the amount of questions directly from the database and puts them into the training
     question pool, if they qualifiy for this(more than 10 questions)

     */
    static {
        try {
            NUMBER_OF_QUESTIONS = TopicEntry.class.getDeclaredField("numberOfQuestions");
            NUMBER_OF_QUESTIONS.setAccessible(true);
            for (TopicEntry topic : SQLUtil.queryPreparedStatement("SELECT * FROM categories;", TopicEntry.class, null)) {
                NUMBER_OF_QUESTIONS.setInt(topic, Questions.getNumberOfQuestionsFromTopicId(topic.getId()));
                Topics.TOPICS.put(topic.getId(), topic);
                if (topic.isValidForTraining()) Topics.TRAINING_TOPICS.put(topic.getId(), topic);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /*
    increases the number of questions and puts the topic into the training question pool, if it qualifies for it now
     */
    public static void increaseTopicCount(TopicEntry topic){
        if (topic == null) return;
        try {
            NUMBER_OF_QUESTIONS.setInt(topic, NUMBER_OF_QUESTIONS.getInt(topic) + 1);
        } catch (IllegalAccessException ignored) {} //should never happen
        if (topic.isValidForTraining()) TRAINING_TOPICS.putIfAbsent(topic.getId(), topic);
    }

    /*
    decreases the number of questions and removes the topic from the training question pool, if it doesnt qualify for it anymore
     */
    public static void decreaseTopicCount(TopicEntry topic){
        if (topic == null) return;
        try {
            NUMBER_OF_QUESTIONS.setInt(topic, NUMBER_OF_QUESTIONS.getInt(topic) - 1);
        } catch (IllegalAccessException ignored) {} //should never happen
        if (!topic.isValidForTraining()) TRAINING_TOPICS.remove(topic.getId());
    }

    /*
        removes the the topic with the given id from the database
     */
    public static void remove(int id) throws Exception {
        TOPICS.remove(id);
        TRAINING_TOPICS.remove(id);
        SQLUtil.executePreparedStatement("DELETE FROM categories WHERE id = ?;", preparedStatement -> preparedStatement.setInt(1, id));
        SQLUtil.executePreparedStatement("DELETE FROM questions WHERE category_id = ?;", preparedStatement -> preparedStatement.setInt(1, id));
    }

    /*
    adds a new topic to the database and the hashmap, initializes them with 0 questions
     */

    public static TopicEntry add(String name) throws Exception {
        if (name == null) return null;
        List<TopicEntry> singleTopicList = SQLUtil.queryPreparedStatement("INSERT INTO categories (name) VALUES (?) ON CONFLICT DO NOTHING RETURNING *;", TopicEntry.class, preparedStatement -> preparedStatement.setString(1, name));
        if (!singleTopicList.isEmpty()) {
            TopicEntry topic = singleTopicList.get(0);
            NUMBER_OF_QUESTIONS.setInt(topic, 0);
            TOPICS.put(topic.getId(), topic);
            return topic;
        }
        return null;
    }

    public static TopicEntry update(int id, String name) throws Exception {
        List<TopicEntry> singleTopicList = SQLUtil.queryPreparedStatement("UPDATE categories SET name = ?  WHERE id = ? RETURNING *;", TopicEntry.class, preparedStatement -> {
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, id);
        });
        if (!singleTopicList.isEmpty()) {
            TopicEntry topic = singleTopicList.get(0);
            NUMBER_OF_QUESTIONS.setInt(topic, getTopic(id).getNumberOfQuestions());
            TOPICS.put(topic.getId(), topic);
            return topic;
        }
        return null;
    }

    /*
    gets the topic object to the given id
     */
    public static TopicEntry getTopic(int id) {
        return TOPICS.get(id);
    }
    /*
    gets a copy of the list of topics
     */
    public static List<TopicEntry> getTopics() {
        return List.copyOf(TOPICS.values());
    }
    /*
    gets a copy of the list of training topics
     */
    public static List<TopicEntry> getTrainingTopics() {
        return List.copyOf(TRAINING_TOPICS.values());
    }
    /* searches for topics in the database    */
    public static List<TopicEntry> searchTopics(String keyword, String page) throws Exception{
        int pageNum;
        try {pageNum = Integer.parseInt(page) - 1;}
        catch (NumberFormatException ignored) {pageNum = 0;}
        return TOPICS.values().stream().filter(topicEntry -> topicEntry.getName().toLowerCase().contains((keyword == null ? "" : keyword.trim()).toLowerCase())).skip(pageNum * 20L).limit(20).toList();

        /*SQLUtil.queryPreparedStatement("SELECT * From categories Where id like ? OR name like ? ORDER BY id limit 20 Offset 20*?;",
                preparedStatement -> {
            preparedStatement.setString(1,'%'+ finalKeyword +'%');
            preparedStatement.setString(2,'%'+ finalKeyword +'%');
            preparedStatement.setInt(3, finalPageNum);

                }, TopicEntry.class);*/
    }
}
