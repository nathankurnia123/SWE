package swe.d6.objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import swe.d6.Main;
import swe.d6.entries.AdminEntry;
import swe.d6.entries.UserEntry;
import swe.d6.helper.Crypt;
import swe.d6.util.SQLUtil;
import swe.d6.util.Validate;
import swe.d6.util.statics.Statics;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Predicate;

public class Users {
    private static final Logger LOGGER = LoggerFactory.getLogger(Users.class);

    /*
    adds a user to the database
    returns null if it doesnt work or a parameter is null
     */
    public static UserEntry addUser(String firstName, String lastName, LocalDate birthDate, String password, int securityQuestion, String securityQuestionAnswer, int firstPlace, int secondPlace, int thirdPlace, boolean admin) throws Exception {
        if (firstName == null || lastName == null || birthDate == null || password == null || securityQuestionAnswer == null)
            return null;
        //warning because of missing id can be ignored because sqlite assigns an id on insertion, autoincrement could be used, but doing it this way is recommended, see: https://www.sqlite.org/autoinc.html
        List<UserEntry> singleUserList = SQLUtil.queryPreparedStatement("""
                        INSERT INTO users (first_name, last_name, discriminator, birthday, password_hash, security_question, answer_hash, first_place, second_place, third_place)
                        VALUES (
                            ?, ?,
                            COALESCE(
                                (SELECT MAX(discriminator) FROM users WHERE first_name = ?),
                                -1
                            ) + 1, ?, ?, ?, ?, ?, ?, ?
                        )ON CONFLICT DO NOTHING RETURNING *;
                        """,
                UserEntry.class, preparedStatement -> {
                    preparedStatement.setString(1, firstName);
                    preparedStatement.setString(2, lastName);
                    preparedStatement.setString(3, firstName);
                    preparedStatement.setString(4, birthDate.format(DateTimeFormatter.ISO_DATE));
                    preparedStatement.setString(5, Crypt.hash(password));
                    preparedStatement.setInt(6, securityQuestion);
                    preparedStatement.setString(7, Crypt.hash(securityQuestionAnswer));
                    preparedStatement.setInt(8, firstPlace);
                    preparedStatement.setInt(9, secondPlace);
                    preparedStatement.setInt(10, thirdPlace);
                });
        UserEntry user = !singleUserList.isEmpty() ? singleUserList.getFirst() : null;
        if (user != null && admin)
            SQLUtil.executePreparedStatement("INSERT INTO admins(user_id) VALUES (?) ON CONFLICT DO NOTHING;", preparedStatement -> preparedStatement.setInt(1, user.getId()));
        return user;
    }

    public static UserEntry updateUser(int userId, String firstName, String lastName, LocalDate birthDate, String password, int securityQuestion, String securityQuestionAnswer, int firstPlace, int secondPlace, int thirdPlace, boolean admin) throws Exception {
        if (firstName == null || lastName == null || birthDate == null || userId == 1) return null;
        List<UserEntry> updatedUserList = SQLUtil.queryPreparedStatement("""
                        UPDATE users
                        SET first_name = ?, last_name = ?, birthday = ?, %ssecurity_question = ?, %sfirst_place = ?, second_place = ?, third_place = ?
                        WHERE id = ?
                        RETURNING *;
                        """.formatted(Validate.checkPassword(password) ? "password_hash = ?, " : "", securityQuestionAnswer != null && !securityQuestionAnswer.isBlank() ? "answer_hash = ?, " : ""),
                UserEntry.class, preparedStatement -> {
                    int i = 1;
                    preparedStatement.setString(i++, firstName);
                    preparedStatement.setString(i++, lastName);
                    preparedStatement.setString(i++, birthDate.format(DateTimeFormatter.ISO_DATE));
                    if (Validate.checkPassword(password)) preparedStatement.setString(i++, Crypt.hash(password));
                    preparedStatement.setInt(i++, securityQuestion);
                    if (securityQuestionAnswer != null && !securityQuestionAnswer.isBlank())
                        preparedStatement.setString(i++, Crypt.hash(securityQuestionAnswer));
                    preparedStatement.setInt(i++, firstPlace);
                    preparedStatement.setInt(i++, secondPlace);
                    preparedStatement.setInt(i++, thirdPlace);
                    preparedStatement.setInt(i++, userId);
                });

        UserEntry user = !updatedUserList.isEmpty() ? updatedUserList.get(0) : null;
        if (user != null) {
            if (admin)
                SQLUtil.executePreparedStatement("INSERT INTO admins(user_id) VALUES (?) ON CONFLICT DO NOTHING;", preparedStatement -> preparedStatement.setInt(1, user.getId()));
            else
                SQLUtil.executePreparedStatement("DELETE FROM admins WHERE user_id = ?;", preparedStatement -> preparedStatement.setInt(1, user.getId()));
        }

        return user;
    }

    public static AdminEntry getAsAdmin(String username) throws Exception {
        if (username == null) return null;
        String[] s = username.split("#", 2);
        if (s.length < 2 || !Validate.checkFirstName(s[0])) return null;
        try {
            int discriminator = Integer.parseInt(s[1]);
            List<AdminEntry> admin = SQLUtil.queryPreparedStatement("""
                    SELECT u.*,
                           CASE
                               WHEN a.user_id IS NOT NULL THEN 1
                               ELSE 0
                           END AS admin
                    FROM users u
                    LEFT JOIN admins a ON u.id = a.user_id
                    WHERE u.first_name = ? AND u.discriminator = ? LIMIT 1;
                    """, AdminEntry.class, preparedStatement -> {
                preparedStatement.setString(1, s[0]);
                preparedStatement.setInt(2, discriminator);
            });
            return admin.isEmpty() ? null : admin.get(0);
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    /*
    gets the user object to the given username
    returns null when username doesnt fit into the namepattern or there is no user to the name
     */

    public static UserEntry getUser(String username) throws Exception {
        if (username == null) return null;
        String[] s = username.split("#", 2);
        if (s.length < 2 || !Validate.checkFirstName(s[0])) return null;
        try {
            int discriminator = Integer.parseInt(s[1]);
            List<UserEntry> users = SQLUtil.queryPreparedStatement("SELECT * FROM users Left Join placements ON placements.user_id = users.id = placements.user_id WHERE first_name = ? AND discriminator = ? LIMIT 1", UserEntry.class, preparedStatement -> {
                preparedStatement.setString(1, s[0]);
                preparedStatement.setInt(2, discriminator);
            });
            return users.isEmpty() ? null : users.get(0);
        } catch (NumberFormatException ignored) {
            return null;
        }
    }
    /*
        gets the next free Discriminator for a username
        returns -1 if the username doesnt fit in the pattern
     */

    public static int getNextDiscriminator(String firstname) throws Exception {
        return Validate.checkFirstName(firstname) ? SQLUtil.queryPreparedStatement("""
                SELECT MAX(discriminator) AS discriminator
                FROM users
                WHERE first_name = ?;
                """, preparedStatement -> preparedStatement.setString(1, firstname), resultSet ->
                resultSet.next() ? resultSet.getObject("discriminator") == null ? 0 : resultSet.getInt("discriminator") + 1 : -1) : -1;
    }

    //TODO: remake
    /*public static User authenticate(String token){
        if (token == null) return null;
        List<User> users = SQLUtil.queryPreparedStatement("SELECT * FROM users WHERE token=? Limit 1", preparedStatement -> {
            preparedStatement.setString(1, StringCrypt.encrypt(token));
        }, User.class);
        return users.isEmpty() ? null : users.get(0);
    }*/

    /*deletes the user with the given id, returns true if it works, false if not                      */
    public static boolean delete(int id) throws Exception {
        if (id == 1) return false;
        List<UserEntry> singleUser = SQLUtil.queryPreparedStatement("delete from users where id=? RETURNING *;",
                UserEntry.class, preparedStatement -> {
                    preparedStatement.setInt(1, id);
                });
        return (!singleUser.isEmpty());
    }

    /*
        gets a list with all admins
     */
    public static List<Integer> getAdmins() throws Exception {
        return SQLUtil.queryPreparedStatement("SELECT * FROM admins", null, resultSet -> {
            List<Integer> admins = new ArrayList<>();
            while (resultSet.next())
                admins.add(resultSet.getInt("user_id"));
            return admins;
        });
    }

    /*
        gets the amount of admins
     */
    public static int numberOfAdmins() throws Exception {
        return getAdmins().size();
    }

    public static void init() throws Exception {
        if (numberOfAdmins() == 0) registerAdminCmd();
        Main.shutdown();
    }

    /*
    registers a Admin through inputs in the cmd
     */
    private static void registerAdminCmd() throws Exception {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("-------------------------------------------------------------");
            System.out.println("Kein Administrator gefunden, bitte erstellen Sie jetzt einen.");
            System.out.println("-------------------------------------------------------------");
            String firstName;
            do {
                System.out.print("Vorname (zwischen 3 und 14 Zeichen ohne #): ");
                firstName = scanner.nextLine();
            } while (!Validate.checkFirstName(firstName));
            String lastName;
            do {
                System.out.print("Nachname (mindestens 3 Zeichen: ");
                lastName = scanner.nextLine();
            } while (!Validate.checkLastName(lastName));
            String password;
            do{
                System.out.print("Passwort (mindestens 8 Zeischen und mit mindestens einer Ziffer und einem Buchstaben): ");
                password = scanner.nextLine();
            } while (!Validate.checkPassword(password));
            String question;
            do{
                System.out.print("Sicherheitsfrage:\n" + String.join("\n", Statics.SECURITY_QUESTIONS_MAP.entrySet().stream().sorted(Comparator.comparing(stringStringEntry -> Integer.parseInt(stringStringEntry.getKey()))).map(stringStringEntry -> stringStringEntry.getKey() + ": " + stringStringEntry.getValue()).toList()) + "\n");
                question = scanner.nextLine();
            } while (Arrays.stream(new String[]{"1", "2", "3", "4", "5"}).noneMatch(Predicate.isEqual(question))); //bad solution, but works
            String answer;
            do{
                System.out.print("Antwort (mindestens 8 Zeichen): ");
                answer = scanner.nextLine();
            } while (answer.length() < 8);
            UserEntry user;
            if ((user = addUser(firstName, lastName, LocalDate.EPOCH, password, Integer.parseInt(question), answer, 0, 0, 0, true)) != null) {
                String userString = "Administrator \"" + user.getFirstName() + "#"+ user.getDiscriminator() + "\" erfolgreich registriert!";
                System.out.println("-".repeat(userString.length()));
                System.out.println(userString);
                System.out.println("-".repeat(userString.length()));
            } else {
                LOGGER.error("Something went wrong");
            }
        }
    }

    /* seaches in the user database for the keyword, id and discriminator and returns all found user in a admin list  */

    public static List<AdminEntry> searchUser(String keyword, String page) throws Exception {
        int pageNum;
        try {
            pageNum = Integer.parseInt(page) - 1;
        } catch (NumberFormatException ignored) {
            pageNum = 0;
        }
        int finalPageNum = pageNum;
        String finalKeyword = keyword != null ? keyword.trim() : "";
        return SQLUtil.queryPreparedStatement("SELECT users.*, iif(a.user_id IS NULL ,0,1) AS admin FROM users LEFT JOIN admins a ON users.id = a.user_id WHERE (first_name ||'#'||discriminator) LIKE ? OR id LIKE ? ORDER BY id LIMIT 20 OFFSET 20*?;",
                AdminEntry.class, preparedStatement -> {
                    preparedStatement.setString(1, '%' + finalKeyword + '%');
                    preparedStatement.setString(2, '%' + finalKeyword + '%');
                    preparedStatement.setInt(3, finalPageNum);
                });
    }

    public static Optional<UserEntry> verifyUserUsingSecurityQuestion(String username, int securityQuestion, String answer) throws Exception {
        UserEntry user = getUser(username);
        return user != null && Crypt.verifyHash(answer, user.getAnswerHash()) && user.getSecurityQuestion() == securityQuestion ? Optional.of(user) : Optional.empty();
    }


    public static boolean setPassword(int userId, String newPassword) throws Exception {
        return SQLUtil.executePreparedStatement("UPDATE users SET password_hash=? WHERE id=?;", preparedStatement -> {
            preparedStatement.setString(1, Crypt.hash(newPassword));
            preparedStatement.setInt(2, userId);
        });
    }
}



