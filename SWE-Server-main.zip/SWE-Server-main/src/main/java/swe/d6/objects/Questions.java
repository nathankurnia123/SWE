package swe.d6.objects;

import swe.d6.entries.QuestionEntry;
import swe.d6.entries.TopicEntry;
import swe.d6.entries.admin.AdminInterfaceQuestionEntity;
import swe.d6.util.SQLUtil;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class Questions {
    private static final Logger LOGGER = LoggerFactory.getLogger(Questions.class);

    private static List<QuestionEntry> dailyGame = List.of();
    private static List<QuestionEntry> weeklyGame = List.of();

    static{
        try {
            List<QuestionEntry> tempDailyGame = SQLUtil.queryPreparedStatement("SELECT * FROM questions WHERE id IN(SELECT question_id FROM game_of_the_day) ORDER BY questions.level;", QuestionEntry.class, null);
            if(tempDailyGame.size() == 15) dailyGame = tempDailyGame;
            else setDailyGame();
            List<QuestionEntry> tempWeeklyGame = SQLUtil.queryPreparedStatement("SELECT * FROM questions WHERE id IN(SELECT question_id FROM last_show) ORDER BY questions.level;", QuestionEntry.class, null);
            if(tempWeeklyGame.size() == 15) weeklyGame = tempWeeklyGame;
            else setWeeklyGame();
        } catch (Exception e) {
            LOGGER.error("Error while setting up Games!", e.getCause());
        }
        
    }

    public static void setDailyGame() throws Exception {
        List<List<QuestionEntry>> temp = SQLUtil.executeBatchSQL(QuestionEntry.class,
        new SQLUtil.SQLObject(
                "INSERT INTO game_of_the_day(_ROWID_, question_id) SELECT level, id FROM (SELECT level, id, ROW_NUMBER() OVER(PARTITION BY level ORDER BY RANDOM()) AS rn FROM questions) tmp WHERE rn = 1 AND level BETWEEN 1 AND 15 ORDER BY level ON CONFLICT(_ROWID_) DO UPDATE SET question_id = excluded.question_id;",
                null,
                false
        ),
        new SQLUtil.SQLObject(
                "SELECT * FROM questions WHERE id IN(SELECT question_id FROM game_of_the_day) ORDER BY questions.level;",
                null,
                true
        ));
        dailyGame = !temp.isEmpty() && temp.getFirst().size() == 15 ? temp.getFirst() : List.of();
    }

    public static void setWeeklyGame() throws Exception {
        List<List<QuestionEntry>> temp = SQLUtil.executeBatchSQL(QuestionEntry.class,
        new SQLUtil.SQLObject(
                "INSERT INTO last_show(_ROWID_, question_id) SELECT level, id FROM (SELECT level, id, ROW_NUMBER() OVER(PARTITION BY level ORDER BY RANDOM()) AS rn FROM questions) tmp WHERE rn = 1 AND level BETWEEN 1 AND 15 ORDER BY level ON CONFLICT(_ROWID_) DO UPDATE SET question_id = excluded.question_id;",
                null,
                false
        ),
        new SQLUtil.SQLObject(
                "SELECT * FROM questions WHERE id IN(SELECT question_id FROM last_show) ORDER BY questions.level;",
                null,
                true
        ));
        weeklyGame = !temp.isEmpty() && temp.getFirst().size() == 15 ? temp.getFirst() : List.of();
    }

    public static List<QuestionEntry> getDailyGame() {
        return dailyGame;
    }

    public static List<QuestionEntry> getWeeklyGame() {
        return weeklyGame;
    }

    /*
    adds a question with the 4 answers (and an integer to identify the right answer), the level and the topic id
    returns null when a parameter is null or the topicid doesnt exist else returns the added question
     */
    public static QuestionEntry add(int rightAnswer, String question, String answer1, String answer2, String answer3, String answer4, int level, int topicId) throws Exception {
        if (question == null || answer1 == null || answer2 == null || answer3 == null || answer4 == null) return null;
        TopicEntry topic;
        if ((topic = Topics.getTopic(topicId)) != null){
            //warning because of missing id can be ignored because sqlite assigns an id on insertion, autoincrement could be used, but doing it this way its recommended, see: https://www.sqlite.org/autoinc.html
            List<QuestionEntry> singleQuestionList = SQLUtil.queryPreparedStatement("INSERT INTO questions (correct_answer, question, answer_a, answer_b, answer_c, answer_d, level, category_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT (question) DO NOTHING RETURNING *;",
                    QuestionEntry.class, preparedStatement -> {
                preparedStatement.setInt(1, rightAnswer);
                preparedStatement.setString(2, question);
                preparedStatement.setString(3, answer1);
                preparedStatement.setString(4, answer2);
                preparedStatement.setString(5, answer3);
                preparedStatement.setString(6, answer4);
                preparedStatement.setInt(7, level);
                preparedStatement.setInt(8, topicId);
                    });
            if (!singleQuestionList.isEmpty()) {
                Topics.increaseTopicCount(topic);
                if (dailyGame.isEmpty()) setDailyGame();
                if (weeklyGame.isEmpty()) setWeeklyGame();
                return singleQuestionList.get(0);
            }
        }
        return null;
    }

    public static QuestionEntry update(int questionId, int rightAnswer, String question, String answer1, String answer2, String answer3, String answer4, int level, int topicId) throws Exception {
        if (question == null || answer1 == null || answer2 == null || answer3 == null || answer4 == null) return null;
        if (Topics.getTopic(topicId) != null) {
            try{
                List<QuestionEntry> updatedQuestionList = SQLUtil.queryPreparedStatement("UPDATE questions SET correct_answer = ?, question = ?, answer_a = ?, answer_b = ?, answer_c = ?, answer_d = ?, level = ?, category_id = ? WHERE id = ? RETURNING *;",
                        QuestionEntry.class, preparedStatement -> {
                            preparedStatement.setInt(1, rightAnswer);
                            preparedStatement.setString(2, question);
                            preparedStatement.setString(3, answer1);
                            preparedStatement.setString(4, answer2);
                            preparedStatement.setString(5, answer3);
                            preparedStatement.setString(6, answer4);
                            preparedStatement.setInt(7, level);
                            preparedStatement.setInt(8, topicId);
                            preparedStatement.setInt(9, questionId);
                        });

                if (!updatedQuestionList.isEmpty()) {
                    return updatedQuestionList.get(0);
                }
            } catch (SQLException e){
                if (e.getErrorCode() != 19) throw e;
            }
        }
        return null;
    }


    public static boolean delete(int questionId) throws Exception {
        List<QuestionEntry> singleQuestion = SQLUtil.queryPreparedStatement("delete from questions where id=? RETURNING *;",
                QuestionEntry.class, preparedStatement -> {
                    preparedStatement.setInt(1, questionId);
                });
        if (!singleQuestion.isEmpty()) {
            Topics.decreaseTopicCount(Topics.getTopic(singleQuestion.get(0).getCategoryId()));
            if (dailyGame.stream().map(QuestionEntry::getId).anyMatch(Predicate.isEqual(questionId))) setDailyGame();
            if (weeklyGame.stream().map(QuestionEntry::getId).anyMatch(Predicate.isEqual(questionId))) setWeeklyGame();
        }
        return (!singleQuestion.isEmpty());
    }

    //gets all questions from the database
    public static List<QuestionEntry> getQuestions() throws Exception {
        return SQLUtil.queryPreparedStatement("SELECT * FROM questions;", QuestionEntry.class, null);
    }

    /*
    should not be used
     */
    /*public static List<Question> getQuestions(int id) throws Exception {
        return SQLUtil.queryPreparedStatement("SELECT * FROM questions WHERE category_id = ?;", preparedStatement -> preparedStatement.setInt(1, id), Question.class);
    }*/

    /*
    gets a random Question from the given level
    returns null when there is no question from the level
     */
    public static QuestionEntry getRandomLevelQuestion(int level) throws Exception {
        final List<QuestionEntry> list = SQLUtil.queryPreparedStatement("SELECT * FROM questions WHERE level = ? ORDER BY random() LIMIT 1;", QuestionEntry.class, preparedStatement -> {
        });
        return list.isEmpty() ? null : list.get(0);
    }
    /*
    gets the number of questions in a topic directly from the database
     */
    public static int getNumberOfQuestionsFromTopicId(int topicId) throws Exception {
        return SQLUtil.queryPreparedStatement("SELECT COUNT(question) AS size FROM questions WHERE category_id = ?;",
                    preparedStatement -> preparedStatement.setInt(1, topicId), resultSet -> {
                if (resultSet.next()) return resultSet.getInt("size");
                return 0;
            });
    }

    //retrieves 10 questions from the selected topics from the database
    public static List<QuestionEntry> getQuestionsFromTopics(int... ids) throws Exception {
        return Arrays.stream(ids).anyMatch(id -> Topics.getTopic(id) == null) ? new ArrayList<>() : SQLUtil.queryPreparedStatement(String.format("SELECT * FROM questions WHERE%s ORDER BY random() LIMIT 10;",
                String.join(" OR", Arrays.stream(ids).mapToObj(i -> " category_id = " + i).toArray(String[]::new))), QuestionEntry.class, null);
    }

    //gets 15 questions from the database, one for each level (1-15)
    public static List<QuestionEntry> getGame() throws Exception {
        List<QuestionEntry> temp = SQLUtil.queryPreparedStatement(
                "SELECT * FROM (SELECT *, ROW_NUMBER() OVER(PARTITION BY level ORDER BY RANDOM()) AS rn FROM questions) tmp WHERE rn = 1 AND level BETWEEN 1 AND 15 ORDER BY level;",
                QuestionEntry.class, null);
        return temp.size() == 15 ? temp : List.of();
    }

    //gets 15 questions from the database and adds them to game_of_the_day database
    public static List<QuestionEntry> getGameOfTheDay() throws Exception{
        return SQLUtil.queryPreparedStatement("INSERT INTO game_of_the_day SELECT id FROM (SELECT *, ROW_NUMBER() OVER(PARTITION BY level ORDER BY RANDOM()) AS rn FROM questions) tmp WHERE rn = 1 AND level BETWEEN 1 AND 15 ORDER BY level RETURNING *;",
        QuestionEntry.class, null);
    }

    //gets the 15 Game of the Day questions
    public static List<QuestionEntry> realGetGameOfTheDay() throws Exception{
        return SQLUtil.queryPreparedStatement("SELECT * From game_of_the_day left join questions q on q.id = game_of_the_day.question_id ORDER BY level;",QuestionEntry.class, null);
    }
    //gets 15 questions from the database and adds them to last_shows database
    public static List<QuestionEntry> getLastShow() throws Exception{
        return SQLUtil.queryPreparedStatement("INSERT INTO last_show (question_id) SELECT id FROM ( SELECT *, ROW_NUMBER() OVER(PARTITION BY level ORDER BY RANDOM()) AS rn FROM questions) tmp WHERE rn = 1 AND level BETWEEN 1 AND 15 ORDER BY level Returning *;",
                QuestionEntry.class, null);
    }

    public static List<QuestionEntry> realGetLastShow() throws Exception{
        return SQLUtil.queryPreparedStatement("SELECT * From last_show left join questions q on q.id = last_show.question_id ORDER BY level;",QuestionEntry.class, null);
    }

    /*searches in the question database for the keyword*/
    public static  List<AdminInterfaceQuestionEntity> searchQuestions(String keyword, String page) throws Exception{
        int pageNum;
        try {pageNum = Integer.parseInt(page) - 1;}
        catch (NumberFormatException ignored) {pageNum = 0;}
        int finalPageNum = pageNum;
        String finalKeyword = keyword != null ? keyword.trim() : "";
        return SQLUtil.queryPreparedStatement("Select q.*, c.name AS topic FROM questions q left join categories c ON q.category_id = c.id Where (q.id like ? OR q.question like ?) ORDER BY q.id limit 20 OFFSET 20*?;",
                AdminInterfaceQuestionEntity.class, preparedStatement -> {
                preparedStatement.setString(1,'%'+ finalKeyword +'%');
                preparedStatement.setString(2,'%'+ finalKeyword +'%');
                preparedStatement.setInt(3, finalPageNum);
                });
        }

}