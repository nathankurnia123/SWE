package swe.d6.objects;

import swe.d6.entries.AdminEntry;
import swe.d6.entries.UserEntry;
import swe.d6.helper.SessionIdEncryptor;
import swe.d6.util.SQLUtil;
import swe.d6.util.statics.Statics;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public class Sessions {
    private static final Field SESSION_ID;
    static {
        try {
            SESSION_ID = UserEntry.class.getDeclaredField("sessionId");
            SESSION_ID.setAccessible(true);
        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        }
    }

    /*
    adds a new entry to session-database with the session-id, user-id and the expiration date of the session
     */
    public static UserEntry addSessionId(UserEntry user) throws Exception {
        if (user == null) return null;
        String sessionId = null;
        for (int i = 0; i <= 10 && sessionId == null; i++) {
            String temp = generate();
            sessionId = SQLUtil.queryPreparedStatement("INSERT INTO sessions(id, user_id, expiration_date) VALUES (?, ?, ?) ON CONFLICT DO NOTHING RETURNING id;", preparedStatement -> {
                preparedStatement.setString(1, SessionIdEncryptor.encryptSessionId(temp));
                preparedStatement.setInt(2, user.getId());
                preparedStatement.setString(3, LocalDate.now().plusMonths(1).format(Statics.FORMATTER));
            }, resultSet -> {
                if (resultSet.next()) return temp;
                return null;
            });
        }
        if (sessionId != null) SESSION_ID.set(user, sessionId);
        return user;
    }

    /*
    gets the user to a given session id
     */
    public static UserEntry getUserFromSessionId(String sessionId) throws Exception {
        if (sessionId == null || sessionId.isEmpty()) return null;
        List<UserEntry> user = SQLUtil.queryPreparedStatement("""
                SELECT users.*
                FROM users
                JOIN sessions ON users.id = sessions.user_id
                WHERE sessions.id = ? LIMIT 1;
                """, UserEntry.class, preparedStatement -> preparedStatement.setString(1,SessionIdEncryptor.encryptSessionId(sessionId)));
        return user.isEmpty() ? null : user.get(0);
    }

    public static AdminEntry getAdminFromSessionId(String sessionId) throws Exception {
        if (sessionId == null || sessionId.isEmpty()) return null;
        List<AdminEntry> admin = SQLUtil.queryPreparedStatement("""
                SELECT u.*,
                       CASE
                           WHEN a.user_id IS NOT NULL THEN 1
                           ELSE 0
                           END AS admin
                FROM users u
                         JOIN sessions s ON u.id = s.user_id
                         LEFT JOIN admins a ON u.id = a.user_id
                WHERE s.id = ?
                LIMIT 1;
                """, AdminEntry.class, preparedStatement -> preparedStatement.setString(1,SessionIdEncryptor.encryptSessionId(sessionId)));
        return admin.isEmpty() ? null : admin.get(0);
    }
    /*
    generates a random session id
     */
    private static String generate() {
        return UUID.randomUUID().toString().replace("-", "");
    }
}
