package swe.d6.converter;

import nl.jiankai.annotations.Converter;
import nl.jiankai.mapper.converters.AttributeConverter;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Converter()
public class DateStringToLocalDateConverter implements AttributeConverter<String, LocalDate> {
    @Override
    public LocalDate convert(String value) {
        return LocalDate.parse(value, DateTimeFormatter.ISO_LOCAL_DATE);
    }

    @Override
    public Class<String> source() {
        return String.class;
    }

    @Override
    public Class<LocalDate> target() {
        return LocalDate.class;
    }
}
