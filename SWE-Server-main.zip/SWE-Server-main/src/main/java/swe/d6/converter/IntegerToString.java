package swe.d6.converter;

import nl.jiankai.annotations.Converter;
import nl.jiankai.mapper.converters.AttributeConverter;

@Converter()
public class IntegerToString implements AttributeConverter<Integer, String> {

    @Override
    public String convert(Integer value) {
        return value == 1 ? "Ja" : "Nein";
    }

    @Override
    public Class<Integer> source() {
        return Integer.class;
    }

    @Override
    public Class<String> target() {
        return String.class;
    }
}
