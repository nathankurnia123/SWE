package swe.d6.converter;

import nl.jiankai.annotations.Converter;
import nl.jiankai.mapper.converters.AttributeConverter;

import java.util.Objects;

@Converter()
public class IntegerToBoolean implements AttributeConverter<Integer, Boolean> {

    @Override
    public Boolean convert(Integer value) {
        return value == 1;
    }

    @Override
    public Class<Integer> source() {
        return Integer.class;
    }

    @Override
    public Class<Boolean> target() {
        return Boolean.class;
    }
}
