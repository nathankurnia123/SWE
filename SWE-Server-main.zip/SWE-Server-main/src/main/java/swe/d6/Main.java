package swe.d6;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import spark.Spark;
import swe.d6.database.SQLManager;
import swe.d6.database.SQLiteConnectionPool;
import swe.d6.helper.HttpToHttpsRedirectServer;
import swe.d6.helper.TaskScheduler;
import swe.d6.objects.Users;
import swe.d6.util.SparkInit;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;

public class Main {
    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);
    private static final Set<String> VALID_COMMANDS = new HashSet<>(Set.of("shutdown", "stop", "exit"));

    public static void main(String[] args) throws Exception {
        SQLManager.init();
        TaskScheduler.init();
        Users.init();
        SparkInit.init();
        HttpToHttpsRedirectServer.startServer();
    }

    public static void shutdown() {
        CompletableFuture.runAsync(() -> {
            try (Scanner scanner = new Scanner(System.in)) {
                String input;
                do {
                    input = scanner.nextLine().toLowerCase(); // Make the comparison case-insensitive
                } while (!VALID_COMMANDS.contains(input));

                LOGGER.info("Shutdown initialised");
                /*
                 * add everything that needs to shut down below
                 */
                HttpToHttpsRedirectServer.stopServer();        //stop http to https redirect server
                Spark.stop();                                  //stop server
                SQLiteConnectionPool.closeDataSource();        //close database connection
                TaskScheduler.shutdown();                      //shutdown scheduler
                Spark.awaitStop();
                LOGGER.info("Shutdown complete");
                System.exit(0);
            }
        }, Executors.newSingleThreadExecutor(r -> {
            Thread thread = new Thread(r, "ShutdownHandlerThread");
            thread.setDaemon(true); // this ensures JVM will exit when main thread finished
            return thread;
        }));
    }
}