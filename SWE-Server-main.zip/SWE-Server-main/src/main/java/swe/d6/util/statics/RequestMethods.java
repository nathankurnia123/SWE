package swe.d6.util.statics;

public enum RequestMethods {
    GET,
    POST,
    PUT,
    DELETE
}
