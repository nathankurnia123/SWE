package swe.d6.util;

import java.util.regex.Pattern;

public class Validate {
    // Regular expression to check if the string contains at least one letter and one number
    private static final String regex = "^(?=.*[a-zA-Z])(?=.*\\d).+$";

    // Compile the regular expression
    private static final Pattern pattern = Pattern.compile(regex);


    /*
    checks if the firstName is valid
     */
    public static boolean checkFirstName(String firstName){
        return firstName != null && firstName.length() >= 3 && firstName.length() <= 14 && !firstName.isBlank() && !firstName.contains("#");
    }

    public static boolean checkLastName(String lastName){
        return lastName != null && lastName.length() >= 3 && !lastName.isBlank();
    }

    public static boolean checkPassword(String password) {
        return password != null && password.length() > 7 && !password.isBlank() && pattern.matcher(password).find();
    }
}
