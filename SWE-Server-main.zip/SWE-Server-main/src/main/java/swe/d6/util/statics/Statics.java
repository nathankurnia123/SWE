package swe.d6.util.statics;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import nl.jiankai.mapper.ResultSetMapper;
import nl.jiankai.mapper.ResultSetMapperFactory;
import swe.d6.converter.DateStringToLocalDateConverter;
import swe.d6.converter.IntegerToBoolean;
import swe.d6.converter.LocalDateTypeAdapter;
import swe.d6.helper.PropertiesFileManager;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class Statics {
    public static final Gson GSON = new GsonBuilder()
            .registerTypeAdapter(LocalDate.class, new LocalDateTypeAdapter())
            .create();

    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static final Properties PROPERTIES = PropertiesFileManager.load();

    public static final Map<String, String> SECURITY_QUESTIONS_MAP = Map.of(
            "1", "Welche Veranstaltung an der FH Aachen hat dich bisher am meisten inspiriert?",
            "2", "Welche Veranstaltung der FH Aachen hat dich am meisten herausgefordert?",
            "3", "Welches Studienfach an der FH Aachen hat für dich die größte praktische Relevanz?",
            "4", "In welcher Forschungsgruppe der FH Aachen würdest du gerne mitarbeiten?",
            "5", "Welche spezielle Einrichtung oder Ressource der Hochschule nutzt du regelmäßig?"
    );
    public static final String SECURITY_QUESTIONS_JSON = GSON.toJson(SECURITY_QUESTIONS_MAP);

    public static final ResultSetMapper MAPPER;

    static {
        MAPPER = ResultSetMapperFactory.getResultSetMapperLowerCaseUnderscore();
        Statics.MAPPER.registerAttributeConverter(new DateStringToLocalDateConverter());
        Statics.MAPPER.registerAttributeConverter(new IntegerToBoolean());
    }
    public static final List<Integer> WINNINGS = List.of(50, 100, 200, 300, 500, 1000, 2000, 4000, 8000, 16000, 32000, 64000, 125000, 500000, 1000000
    );
}
