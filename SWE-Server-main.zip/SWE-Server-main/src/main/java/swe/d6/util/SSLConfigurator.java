package swe.d6.util;

import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.X500NameBuilder;
import org.bouncycastle.asn1.x500.style.BCStyle;
import org.bouncycastle.asn1.x509.BasicConstraints;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import spark.Spark;

import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.Date;

//https://stackoverflow.com/questions/29852290/self-signed-x509-certificate-with-bouncy-castle-in-java

public class SSLConfigurator {

    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    public void configureSSL() throws NoSuchAlgorithmException, OperatorCreationException,
            IOException, CertificateException, InvalidKeyException, SignatureException, NoSuchProviderException, KeyStoreException {

        // Generate a self-signed certificate
        X509Certificate certificate = generateSelfSignedCertificate();

        // Save the certificate and private key to files
        saveCertificateAndKey(certificate);

        // Configure Spark with SSL
        Spark.secure("keystore.jks", "password", null, null);
    }

    private X509Certificate generateSelfSignedCertificate() throws NoSuchAlgorithmException, OperatorCreationException,
            IOException, CertificateException, InvalidKeyException, SignatureException, NoSuchProviderException {

        // Key pair generation
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA", BouncyCastleProvider.PROVIDER_NAME);
        keyPairGenerator.initialize(2048);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();

        Provider bcProvider = new BouncyCastleProvider();
        Security.addProvider(bcProvider);

        long now = System.currentTimeMillis();
        Date startDate = new Date(now);

        X500Name dnName = new X500NameBuilder()
                .addRDN(BCStyle.C, "AU")
                .addRDN(BCStyle.O, "The Legion of the Bouncy Castle")
                .addRDN(BCStyle.L, "Melbourne")
                .addRDN(BCStyle.ST, "Victoria")
                .addRDN(BCStyle.E, "feedback-crypto@bouncycastle.org")
                .addRDN(BCStyle.CN, "0.0.0.0")
                .build();
        BigInteger certSerialNumber = new BigInteger(Long.toString(now)); // <-- Using the current timestamp as the certificate serial number

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        calendar.add(Calendar.YEAR, 1); // <-- 1 Yr validity

        Date endDate = calendar.getTime();

        String signatureAlgorithm = "SHA256WithRSA"; // <-- Use appropriate signature algorithm based on your keyPair algorithm.

        ContentSigner contentSigner = new JcaContentSignerBuilder(signatureAlgorithm).build(keyPair.getPrivate());

        JcaX509v3CertificateBuilder certBuilder = new JcaX509v3CertificateBuilder(dnName, certSerialNumber, startDate, endDate, dnName, keyPair.getPublic());

        // Extensions --------------------------

        // Basic Constraints
        BasicConstraints basicConstraints = new BasicConstraints(true); // <-- true for CA, false for EndEntity

        certBuilder.addExtension(new ASN1ObjectIdentifier("2.5.29.19"), true, basicConstraints); // Basic Constraints is usually marked as critical.

        // -------------------------------------

        return new JcaX509CertificateConverter().setProvider(bcProvider).getCertificate(certBuilder.build(contentSigner));
    }

    private void saveCertificateAndKey(X509Certificate certificate)
            throws IOException, CertificateException, KeyStoreException, NoSuchAlgorithmException {

        // Create a KeyStore and add the certificate to it
        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        keyStore.load(null, null); // Initialize an empty keystore
        String alias = "alias"; // You can choose any alias for the certificate
        keyStore.setCertificateEntry(alias, certificate);

        // Save the KeyStore to a file (optional)
        // Note: The password for the keystore is typically set when saving it to a file
        keyStore.store(Files.newOutputStream(Path.of("keystore.jks")), "password".toCharArray());
    }
}