package swe.d6.util;

import java.io.*;
import java.net.URL;

public class FileReader {
    public static String asString(URL url) {
        if (url != null){
            StringBuilder resultStringBuilder = new StringBuilder();
            try (InputStream inputStream = url.openStream()){
                try (BufferedReader br
                             = new BufferedReader(new InputStreamReader(inputStream))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        resultStringBuilder.append(line).append("\n");
                    }
                }
                return resultStringBuilder.toString();
            } catch (IOException ignored) {}
        }
        return null;
    }
}
