package swe.d6.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import swe.d6.Main;
import swe.d6.database.SQLiteConnectionPool;
import swe.d6.interfaces.ExceptionFunction;
import swe.d6.interfaces.ExceptionConsumer;
import swe.d6.util.statics.Statics;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for executing SQL queries and statements using prepared statements.
 */
public class SQLUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(SQLUtil.class);


    /**
     * Executes a prepared statement with the given SQL query and consumer.
     *
     * @param sql the SQL query for the prepared statement
     * @param consumer the consumer to apply to the prepared statement
     * @return true if the first result is a ResultSet object; false if the first result is an update count or there is no result
     * @throws SQLException if a database access error occurs or the given SQL statement produces a ResultSet object
     */
    public static boolean executePreparedStatement(String sql, ExceptionConsumer<PreparedStatement> consumer) throws Exception {
        try (Connection connection = SQLiteConnectionPool.getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                if (consumer != null) consumer.accept(statement);
                return statement.execute();
            }
        }
    }

    /**
     * Executes a SQL query with a prepared statement using a connection from the connection pool.
     *
     * @param sql      the SQL statement to be executed
     * @param consumer a consumer function that accepts a PreparedStatement and sets any required parameters
     * @param callable a function that accepts a ResultSet and returns a result of type T
     * @param <T>      the type of the result
     * @return the result of the query
     * @throws SQLException if an error occurs while executing the query or interacting with the database
     */
    public static <T> T queryPreparedStatement(String sql, ExceptionConsumer<PreparedStatement> consumer, ExceptionFunction<T, ResultSet> callable) throws Exception {
        try (Connection connection = SQLiteConnectionPool.getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                if (consumer != null) consumer.accept(statement);
                return callable.apply(statement.executeQuery());
            }
        }
    }

    /**
     * Executes a SQL query using a prepared statement and returns the result.
     *
     * @param <T>      the type of the objects in the list
     * @param sql      the SQL statement to be executed
     * @param clazz    the class type used to map the result set to a list of objects
     * @param consumer the SQL exception consumer to be applied to the prepared statement
     * @return a list of objects of type T representing the result of the query
     * @throws SQLException if a database access error occurs or the SQL syntax is invalid
     */
    public static<T> List<T> queryPreparedStatement(String sql, Class<T> clazz, ExceptionConsumer<PreparedStatement> consumer) throws Exception {
        try (Connection connection = SQLiteConnectionPool.getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                if (consumer != null) consumer.accept(statement);
                return Statics.MAPPER.map(statement.executeQuery(), clazz);
            }
        }
    }

    public static <T> List<List<T>> executeBatchSQL(Class<T> clazz, SQLObject... sqlObjects) throws Exception {
        List<List<T>> results = new ArrayList<>();
        Connection connection = null;
        try {
            connection = SQLiteConnectionPool.getConnection();
            connection.setAutoCommit(false);
            connection.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);
            for (SQLObject sqlObject : sqlObjects) {
                try (PreparedStatement statement = connection.prepareStatement(sqlObject.sql)) {
                    if (sqlObject.consumer != null) {
                        sqlObject.consumer.accept(statement);
                    }
                    statement.execute();
                    if(sqlObject.isQuery && clazz != null) {
                        ResultSet resultSet = statement.getResultSet();
                        results.add(Statics.MAPPER.map(resultSet, clazz/*sqlObject.clazz*/));
                    }
                }
            }
            connection.commit();
        } catch (SQLException e) {
            LOGGER.error("Error executing SQL batch:", e);
            if (connection != null) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackException) {
                    LOGGER.error("Error rolling back transaction:", rollbackException);
                }
            }
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException closeException) {
                    // Log the close error
                    LOGGER.error("Error closing connection:", closeException);
                }
            }
        }
        return results;
    }
    public record SQLObject(String sql, ExceptionConsumer<PreparedStatement> consumer, boolean isQuery/*, Class<?> clazz*/) {
    }
}
