package swe.d6.util;

import spark.Request;
import spark.Response;
import spark.Spark;
import swe.d6.helper.RouteRegister;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class SparkInit {
    public static void init() throws InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException, IOException {
        Spark.ipAddress("0.0.0.0");
        Spark.port(443);
        Spark.threadPool(100, 4, 10000);
        JksCertificateGenerator.configureSSL();
        Spark.internalServerError(SparkInit::error);
        Spark.notFound(SparkInit::error);
        Spark.after((request, response) -> response.compression = Response.Compression.AUTO);
        RouteRegister.registerRoutes("swe.d6.routes");
        RouteRegister.registerStaticFileRoute("website");
        Spark.init();
    }

    public static Object error(Request request, Response response){
        response.type("text/html");
        return "<html><body><h2>" + response.status() + "</h2></body></html>";
    }
}
