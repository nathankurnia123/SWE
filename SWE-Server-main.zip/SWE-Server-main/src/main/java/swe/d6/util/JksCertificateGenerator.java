package swe.d6.util;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.X500NameBuilder;
import org.bouncycastle.asn1.x500.style.BCStyle;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import spark.Spark;

import java.io.File;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Date;

public class JksCertificateGenerator {

    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    public static void configureSSL() {
        if (!(new File("keystore.jks")).exists())
            try {
                String keystoreFilePath = "keystore.jks";
                String keyAlias = "myKeyAlias";
                String keystorePassword = "password";
                String keyPassword = "password";
                String distinguishedName = "CN=Example, OU=Development, O=Example Inc, L=City, ST=State, C=US";
                int validityDays = 365000;

                // Generate KeyPair
                KeyPair keyPair = generateKeyPair();

                // Generate X.509 Certificate
                Certificate certificate = generateX509Certificate(keyPair, distinguishedName, validityDays);

                // Create a KeyStore and store the key pair and certificate
                KeyStore keyStore = KeyStore.getInstance("JKS");
                keyStore.load(null, keystorePassword.toCharArray());
                keyStore.setKeyEntry(keyAlias, keyPair.getPrivate(), keyPassword.toCharArray(), new Certificate[]{certificate});

                // Save the KeyStore to a file
                try (FileOutputStream fos = new FileOutputStream(keystoreFilePath)) {
                    keyStore.store(fos, keystorePassword.toCharArray());
                    System.out.println("Keystore file created successfully at: " + keystoreFilePath);
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        Spark.secure("keystore.jks", "password", null, null);
    }

    private static KeyPair generateKeyPair() throws Exception {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);
        return keyPairGenerator.generateKeyPair();
    }

    private static Certificate generateX509Certificate(KeyPair keyPair, String distinguishedName, int validityDays) throws Exception {
        // You can customize certificate details such as algorithm, signature algorithm, extensions, etc.
        // For simplicity, this example uses a basic self-signed X.509 certificate.
        return CertificateGenerator.generateSelfSignedX509Certificate(keyPair, distinguishedName, validityDays);
    }
}

class CertificateGenerator {

    public static X509Certificate generateSelfSignedX509Certificate(KeyPair keyPair, String distinguishedName, int validityDays)
            throws NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, SignatureException, CertificateException {
        X509Certificate cert = null;
        try {
            X500NameBuilder nameBuilder = new X500NameBuilder(BCStyle.INSTANCE);
            nameBuilder.addRDN(BCStyle.CN, distinguishedName);

            X500Name subjectName = nameBuilder.build();
            BigInteger serialNumber = BigInteger.valueOf(System.currentTimeMillis());

            X509v3CertificateBuilder certBuilder = new X509v3CertificateBuilder(
                    subjectName,
                    serialNumber,
                    new Date(),
                    new Date(System.currentTimeMillis() + (long) validityDays * 24 * 60 * 60 * 1000),
                    subjectName,
                    SubjectPublicKeyInfo.getInstance(keyPair.getPublic().getEncoded())
            );

            ContentSigner contentSigner = new JcaContentSignerBuilder("SHA256WithRSAEncryption")
                    .build(keyPair.getPrivate());

            X509CertificateHolder certHolder = certBuilder.build(contentSigner);

            cert = new JcaX509CertificateConverter()
                    .setProvider("BC")
                    .getCertificate(certHolder);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return cert;
    }
}
