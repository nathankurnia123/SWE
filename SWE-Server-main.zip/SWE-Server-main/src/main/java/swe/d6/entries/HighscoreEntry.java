package swe.d6.entries;

public class HighscoreEntry {
    private int user_id;

    private String username;

    private int highscoreMonth;

    private int highscoreWeek;

    private int highscoreDay;


    public void setUser_id(int id){
        user_id=id;
    }

    public int getUser_id(){
        return user_id;

    }

    public void setUsername(String username){
        this.username=username;
    }

    public String getUsername(){
        return username;
    }

    public void setHighscoreMonth(int highscore){
        highscoreMonth=highscore;
    }

    public int getHighscoreMonth(){
        return highscoreMonth;
    }

    public void setHighscoreWeek(int highscore){
        highscoreWeek=highscore;
    }
    public int getHighscoreWeek(){
        return highscoreWeek;
    }

    public void setHighscoreDay(int highscore){
        highscoreDay=highscore;
    }

    public int getHighscoreDay(){
        return highscoreDay;
    }
}
