package swe.d6.entries;
public class GameOfTheDayEntry {

    private int questionId;

    public int getQuestionId(){
        return questionId;
    }
}