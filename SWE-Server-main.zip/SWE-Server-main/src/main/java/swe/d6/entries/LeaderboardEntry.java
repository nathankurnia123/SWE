package swe.d6.entries;

import nl.jiankai.annotations.SuppressWarnings;

public class LeaderboardEntry {
    @SuppressWarnings
    private int rank;
    private int userId;
    private String firstName;
    private int discriminator;
    @SuppressWarnings
    private Integer dailyScore;
    @SuppressWarnings
    private Integer weeklyScore;
    @SuppressWarnings
    private Integer monthlyScore;
    @SuppressWarnings
    private int firstPlace;
    @SuppressWarnings
    private int secondPlace;
    @SuppressWarnings
    private int thirdPlace;

    public int getUserId() {
        return userId;
    }
}
