package swe.d6.entries.admin;

import swe.d6.entries.QuestionEntry;

public class AdminInterfaceQuestionEntity extends QuestionEntry {
    String topic;
}
