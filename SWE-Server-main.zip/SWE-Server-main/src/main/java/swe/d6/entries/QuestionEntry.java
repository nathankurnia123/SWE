package swe.d6.entries;


public class QuestionEntry {
    private int id;
    private int correctAnswer;
    private String question;
    private String answerA;
    private String answerB;
    private String answerC;
    private String answerD;
    private int level;
    private int categoryId;

    public int getId() {
        return id;
    }

    public int getCorrectAnswer() {
        return correctAnswer;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswera() {
        return answerA;
    }

    public String getAnswerb() {
        return answerB;
    }

    public String getAnswerc() {
        return answerC;
    }

    public String getAnswerd() {
        return answerD;
    }

    public int getLevel() {
        return level;
    }

    public int getCategoryId() {
        return categoryId;
    }
}
