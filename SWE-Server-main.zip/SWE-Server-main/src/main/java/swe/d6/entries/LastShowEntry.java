package swe.d6.entries;

public class LastShowEntry {
    private int questionId;

    public int getQuestionId() {
        return questionId;
    }
}