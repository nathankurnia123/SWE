package swe.d6.entries;

import nl.jiankai.annotations.Convert;
import nl.jiankai.annotations.Ignore;
import nl.jiankai.annotations.SuppressWarnings;
import swe.d6.converter.DateStringToLocalDateConverter;

import java.time.LocalDate;

public class UserEntry {
    private int id;
    private String firstName;
    private String lastName;
    private int discriminator;
    @Convert(converter = DateStringToLocalDateConverter.class)
    private LocalDate birthday;
    private transient String passwordHash;
    private int securityQuestion;
    private transient String answerHash;

    private int firstPlace;
    private int secondPlace;
    private int thirdPlace;
    @SuppressWarnings
    private Integer rank;
    @Ignore
    private String sessionId;

    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getDiscriminator() {
        return discriminator;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public int getSecurityQuestion() {
        return securityQuestion;
    }
    public String getAnswerHash(){return answerHash;}
    public int getFirstPlace(){return firstPlace;}
    public int getSecondPlace(){return secondPlace;}
    public int getThirdPlace(){return thirdPlace;}
    public int getRank(){return rank;};
    public String getSessionId() {
        return sessionId;
    }
}
