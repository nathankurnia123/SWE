package swe.d6.entries;

import nl.jiankai.annotations.Ignore;

public class TopicEntry {
    private int id;
    private String name;
    @Ignore
    private int numberOfQuestions;
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getNumberOfQuestions() {
        return numberOfQuestions;
    }

    public boolean isValidForTraining() {
        return numberOfQuestions >= 10;
    }

    private void setNumberOfQuestions(int numberOfQuestions) {
        this.numberOfQuestions = numberOfQuestions;
    }

    private void add(){
        numberOfQuestions++;
    }

    private void remove(){
        numberOfQuestions--;
    }
}
