package swe.d6.entries;


public class GameEntry {
    private int id;
    private int userId;
    private String date;
    private int winnings;


    public int getId(){
        return id;
    }

    public int getUserId(){
        return userId;
    }

    public String getDate(){
        return date;
    }

    public int getWinnings() {
        return winnings;
    }


}