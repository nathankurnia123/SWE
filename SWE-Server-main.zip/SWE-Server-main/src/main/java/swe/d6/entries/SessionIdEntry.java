package swe.d6.entries;

public class SessionIdEntry {
    private String sessionId;
    private int userId;

    public String getSessionId(){
        return sessionId;
    }

    public int getUserId(){
        return userId;
    }
}