package swe.d6.entries;

public class PlacementEntry {
    private int placement;
    private int userId;


    public int getUserId(){
        return userId;
    }

    public int getPlacement(){
        return placement;
    }

}