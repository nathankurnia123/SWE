package swe.d6.entries;

import nl.jiankai.annotations.Convert;
import swe.d6.converter.IntegerToBoolean;

public class AdminEntry extends UserEntry {
    @Convert(converter = IntegerToBoolean.class)
    private boolean admin;

    public boolean isAdmin() {
        return admin;
    }
}