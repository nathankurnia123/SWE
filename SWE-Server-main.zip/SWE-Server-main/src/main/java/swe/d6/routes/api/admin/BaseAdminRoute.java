package swe.d6.routes.api.admin;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.entries.AdminEntry;
import swe.d6.objects.Sessions;

public abstract class BaseAdminRoute implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        String sessionId = request.cookie("sessionId");
        AdminEntry admin = Sessions.getAdminFromSessionId(sessionId);
        if (admin != null && admin.isAdmin()){
            Object object = handler(request, response);
            if(object != null) return object;
        }
        response.redirect("/admin/login", 302);
        return "";
    }

    public abstract Object handler(Request request, Response response) throws Exception;
}
