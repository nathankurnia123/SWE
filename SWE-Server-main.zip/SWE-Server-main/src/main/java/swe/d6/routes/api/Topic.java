package swe.d6.routes.api;

import spark.Request;
import spark.Response;
import spark.Route;

public class Topic implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        return null;
    }
}
