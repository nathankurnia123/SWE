package swe.d6.routes.api;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.entries.QuestionEntry;
import swe.d6.interfaces.RouteMapping;
import swe.d6.objects.Questions;

import java.util.List;

import static swe.d6.util.statics.Statics.GSON;

@RouteMapping()
public class Training implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        try {
            String topicId = request.queryParams("topicId");
            if (topicId != null && !topicId.isEmpty()){
                int id = Integer.parseInt(topicId);
                List<QuestionEntry> questions = Questions.getQuestionsFromTopics(id);
                if(!questions.isEmpty()) return GSON.toJson(questions);
            }
        } catch (NumberFormatException ignored){}
        response.status(400);
        return "";
    }
}
