package swe.d6.routes.api.admin;

import spark.Request;
import spark.Response;
import swe.d6.interfaces.RouteMapping;
import swe.d6.objects.Questions;
import swe.d6.objects.Topics;
import swe.d6.objects.Users;
import swe.d6.util.Validate;
import swe.d6.util.statics.RequestMethods;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeParseException;
import java.util.Objects;

import static swe.d6.util.statics.Statics.FORMATTER;

@RouteMapping(method = RequestMethods.POST)
public class Edit extends BaseAdminRoute {
    @Override
    public Object handler(Request request, Response response) throws Exception {
        String type = request.queryParams("type");
        if (type != null) switch (type) {
            case "users":
                return editUser(request, response);
            case "questions":
                return editQuestion(request, response);
            case "topics":
                return editTopic(request, response);
        }
        else response.status(400);
        return "";
    }

    private Object editUser(Request request, Response response) throws Exception {
        try {
            int id = Integer.parseInt(request.queryParams("_id"));
            String firstName = request.queryParams("firstName");
            String lastName = request.queryParams("lastName");
            LocalDate birthday = LocalDate.parse(Objects.requireNonNullElseGet(request.queryParams("birthday"), String::new), FORMATTER);
            String password = request.queryParams("password");
            int securityQuestion = Integer.parseInt(request.queryParams("securityQuestion"));
            String securityQuestionAnswer = request.queryParams("securityQuestionAnswer");
            int firstPlace = Integer.parseInt(request.queryParamOrDefault("firstPlace", "0"));
            int secondPlace = Integer.parseInt(request.queryParamOrDefault("secondPlace", "0"));
            int thirdPlace = Integer.parseInt(request.queryParamOrDefault("thirdPlace", "0"));
            boolean admin = Objects.equals(request.queryParams("admin"), "1");
            if (Validate.checkFirstName(firstName) && Validate.checkLastName(lastName) &&
                    Period.between(birthday, LocalDate.now()).getYears() >= 15 && securityQuestion <= 5 && securityQuestion >= 1 &&
                    firstPlace >= 0 && secondPlace >= 0 && thirdPlace >= 0) {
                return Users.updateUser(id, firstName, lastName, birthday, password, securityQuestion, securityQuestionAnswer, firstPlace, secondPlace, thirdPlace, admin).getDiscriminator();
            }
        } catch (DateTimeParseException | NumberFormatException ignored) {
        }
        response.status(400);
        return "";
    }

    private Object editQuestion(Request request, Response response) throws Exception {
        try {
            int id = Integer.parseInt(request.queryParams("_id"));
            int categoryId = Integer.parseInt(request.queryParams("topic"));
            int level = Integer.parseInt(request.queryParams("level"));
            String question = request.queryParams("question");
            String answerA = request.queryParams("answerA");
            String answerB = request.queryParams("answerB");
            String answerC = request.queryParams("answerC");
            String answerD = request.queryParams("answerD");
            int correctAnswer = Integer.parseInt(request.queryParams("correctAnswer"));
            if (swe.d6.objects.Topics.getTopic(categoryId) != null && level > 0 && level < 16 && !question.isBlank() && !answerA.isBlank() && !answerB.isBlank() && !answerC.isBlank() && !answerD.isBlank() && correctAnswer > 0 && correctAnswer < 5) {
                if (Questions.update(id, correctAnswer, question, answerA, answerB, answerC, answerD, level, categoryId) != null)
                    return "";
            }
        } catch (NumberFormatException ignored) {}
        response.status(400);
        return "";
    }

    private Object editTopic(Request request, Response response) throws Exception {
        try {
            int id = Integer.parseInt(request.queryParams("_id"));
            String topic = request.queryParams("name");
            if (topic != null && !topic.isBlank() && Topics.update(id, topic) != null) return "";
        } catch (NumberFormatException ignored) {
        }
        response.status(400);
        return "";
    }
}
