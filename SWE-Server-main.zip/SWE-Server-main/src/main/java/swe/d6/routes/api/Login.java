package swe.d6.routes.api;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.entries.UserEntry;
import swe.d6.helper.Crypt;
import swe.d6.interfaces.RouteMapping;
import swe.d6.objects.Sessions;
import swe.d6.objects.Users;
import swe.d6.util.statics.RequestMethods;

import static swe.d6.util.statics.Statics.GSON;

@RouteMapping(method = RequestMethods.POST)
public class Login implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        String username = request.queryParams("username");
        String password = request.queryParams("password");
        if (username != null && password != null){
            UserEntry user = Users.getUser(username);
            if (user != null && Crypt.verifyHash(password, user.getPasswordHash()))
                return GSON.toJson(Sessions.addSessionId(user));
            else {
                response.status(401);
                return "";
            }
        }
        response.status(400);
        return "";
    }
}
