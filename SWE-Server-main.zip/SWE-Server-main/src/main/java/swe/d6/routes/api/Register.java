package swe.d6.routes.api;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.interfaces.RouteMapping;
import swe.d6.objects.Sessions;
import swe.d6.objects.Users;
import swe.d6.util.Validate;
import swe.d6.util.statics.RequestMethods;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeParseException;
import java.util.Objects;

import static swe.d6.util.statics.Statics.GSON;
import static swe.d6.util.statics.Statics.FORMATTER;

@RouteMapping(method = RequestMethods.POST)
public class Register implements Route {

    @Override
    public Object handle(Request request, Response response) throws Exception {
        try {
            String firstName = request.queryParams("firstName");
            String lastName = request.queryParams("lastName");
            LocalDate date = LocalDate.parse(Objects.requireNonNullElseGet(request.queryParams("birthday"), String::new) , FORMATTER);
            String password = request.queryParams("password");
            int securityQuestion = Integer.parseInt(request.queryParams("securityQuestion"));
            String securityQuestionAnswer = request.queryParams("securityQuestionAnswer");
            if (Validate.checkFirstName(firstName) && Validate.checkLastName(lastName) && Period.between(date, LocalDate.now()).getYears() >= 15
                    && Validate.checkPassword(password) && securityQuestion <= 5 && securityQuestion >= 1 && securityQuestionAnswer != null) {
                return GSON.toJson(Sessions.addSessionId(Users.addUser(firstName, lastName, date, password, securityQuestion, securityQuestionAnswer, 0, 0, 0, false)));
            }
        }catch (NumberFormatException | DateTimeParseException ignored){}
        response.status(400);
        return "";
    }
}
