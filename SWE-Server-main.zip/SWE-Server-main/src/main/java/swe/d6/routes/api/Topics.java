package swe.d6.routes.api;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.interfaces.RouteMapping;

import static swe.d6.util.statics.Statics.GSON;

@RouteMapping
public class Topics implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        return GSON.toJson(swe.d6.objects.Topics.getTrainingTopics());
    }
}
