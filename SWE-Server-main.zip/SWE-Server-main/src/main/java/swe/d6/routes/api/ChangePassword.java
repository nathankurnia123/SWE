package swe.d6.routes.api;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.entries.UserEntry;
import swe.d6.interfaces.RouteMapping;
import swe.d6.objects.Users;
import swe.d6.util.Validate;
import swe.d6.util.statics.RequestMethods;

import java.util.Optional;

import static swe.d6.util.statics.Statics.GSON;

@RouteMapping(method = RequestMethods.POST)
public class ChangePassword implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        try {
            String username = request.queryParams("username");
            int securityQuestion = Integer.parseInt(request.queryParams("securityQuestion"));
            String securityQuestionAnswer = request.queryParams("securityQuestionAnswer");
            Optional<UserEntry> user = Users.verifyUserUsingSecurityQuestion(username, securityQuestion, securityQuestionAnswer);
            if (user.isPresent()){
                String newPassword = request.queryParams("password");
                if (Validate.checkPassword(newPassword)) Users.setPassword(user.get().getId(), newPassword);
                return GSON.toJson(user.get());
            }
        } catch (NumberFormatException ignored){};
        response.status(401);
        return "";
    }
}
