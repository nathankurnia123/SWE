package swe.d6.routes.api.admin;

import spark.Request;
import spark.Response;
import swe.d6.helper.TaskScheduler;
import swe.d6.interfaces.RouteMapping;

@RouteMapping
public class Debug extends BaseAdminRoute {
    @Override
    public Object handler(Request request, Response response) throws Exception {
        String run = request.queryParams("run");
        switch (run) {
            case "daily" -> TaskScheduler.dailyTask();
            case "weekly" -> TaskScheduler.weeklyTask();
            case "monthly" -> TaskScheduler.monthlyTasks();
            default -> response.status(400);
        }
        return "";
    }
}
