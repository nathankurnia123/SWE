package swe.d6.routes.api;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.entries.UserEntry;
import swe.d6.interfaces.RouteMapping;
import swe.d6.objects.Sessions;
import swe.d6.util.SQLUtil;
import swe.d6.util.statics.RequestMethods;
import swe.d6.util.statics.Statics;

import static swe.d6.util.statics.Statics.WINNINGS;

@RouteMapping(method = RequestMethods.POST)
public class EndGame implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        String sessionId = request.queryParams("sessionId");
        try {
            int score = Integer.parseInt(request.queryParams("score"));
            UserEntry user = Sessions.getUserFromSessionId(sessionId);
            if (user != null && WINNINGS.contains(score)) {
                if (score > 0)
                    SQLUtil.executeBatchSQL(null,
                            new SQLUtil.SQLObject("INSERT INTO daily_scores (user_id, score) VALUES (?, ?) ON CONFLICT (user_id) DO UPDATE SET score = score + excluded.score WHERE user_id = excluded.user_id", preparedStatement -> {
                                preparedStatement.setInt(1, user.getId());
                                preparedStatement.setInt(2, score);
                                    }, false),
                            new SQLUtil.SQLObject("INSERT INTO weekly_scores (user_id, score) VALUES (?, ?) ON CONFLICT (user_id) DO UPDATE SET score = score + excluded.score WHERE user_id = excluded.user_id", preparedStatement -> {
                                preparedStatement.setInt(1, user.getId());
                                preparedStatement.setInt(2, score);
                            }, false),
                            new SQLUtil.SQLObject("INSERT INTO monthly_scores (user_id, score) VALUES (?, ?) ON CONFLICT (user_id) DO UPDATE SET score = score + excluded.score WHERE user_id = excluded.user_id", preparedStatement -> {
                                preparedStatement.setInt(1, user.getId());
                                preparedStatement.setInt(2, score);
                            }, false)
                    );
                return "";
            }
        } catch (Exception e) {
            if (!(e instanceof NumberFormatException)) throw e;
        }
        response.status(400);
        return "";
    }
}
