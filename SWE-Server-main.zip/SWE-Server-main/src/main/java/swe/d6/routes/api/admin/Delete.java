package swe.d6.routes.api.admin;

import spark.Request;
import spark.Response;
import swe.d6.interfaces.RouteMapping;
import swe.d6.objects.Leaderboards;
import swe.d6.objects.Questions;
import swe.d6.objects.Topics;
import swe.d6.objects.Users;
import swe.d6.util.statics.RequestMethods;

@RouteMapping(method = RequestMethods.POST)
public class Delete extends BaseAdminRoute{
    @Override
    public Object handler(Request request, Response response) throws Exception {
        try {
            String type = request.queryParams("type");
            int id = Integer.parseInt(request.queryParams("id"));
            if (type != null) switch (type){
                case "users" -> Users.delete(id);
                case "questions" -> Questions.delete(id);
                case "topics" -> Topics.remove(id);
                case "leaderboards" -> Leaderboards.resetUserScores(id);
            }
            else response.status(400);
        } catch (NumberFormatException ignored){response.status(400);}
        return "";
    }
}
