package swe.d6.routes.api.admin;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.interfaces.RouteMapping;
import swe.d6.util.statics.RequestMethods;

@RouteMapping
public class Logout implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        response.removeCookie("/", "sessionId");
        response.redirect("/admin/login");
        return "";
    }
}
