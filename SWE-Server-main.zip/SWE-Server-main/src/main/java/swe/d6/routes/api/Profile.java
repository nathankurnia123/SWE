package swe.d6.routes.api;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.entries.UserEntry;
import swe.d6.interfaces.RouteMapping;
import swe.d6.objects.Sessions;
import swe.d6.util.statics.RequestMethods;

import static swe.d6.util.statics.Statics.GSON;

@RouteMapping(method = RequestMethods.POST)
public class Profile implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        String sessionId = request.queryParams("sessionId");
        UserEntry user = Sessions.getUserFromSessionId(sessionId);
        if (user != null) return GSON.toJson(user);
        response.status(400);
        return "";
    }
}
