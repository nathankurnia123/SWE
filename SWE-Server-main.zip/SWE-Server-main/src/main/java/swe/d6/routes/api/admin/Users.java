package swe.d6.routes.api.admin;

import spark.Request;
import spark.Response;
import swe.d6.interfaces.RouteMapping;

import static swe.d6.util.statics.Statics.GSON;

@RouteMapping
public class Users extends BaseAdminRoute {
    @Override
    public Object handler(Request request, Response response) throws Exception {
        String query = request.queryParams("q");
        String page = request.queryParams("p");
        return GSON.toJson(swe.d6.objects.Users.searchUser(query, page));
    }
}
