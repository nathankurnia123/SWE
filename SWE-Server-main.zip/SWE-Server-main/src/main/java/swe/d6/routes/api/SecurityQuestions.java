package swe.d6.routes.api;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.interfaces.RouteMapping;

import static swe.d6.util.statics.Statics.SECURITY_QUESTIONS_JSON;
@RouteMapping
public class SecurityQuestions implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        return SECURITY_QUESTIONS_JSON;
    }
}
