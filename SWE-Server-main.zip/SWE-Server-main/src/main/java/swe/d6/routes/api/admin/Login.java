package swe.d6.routes.api.admin;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.entries.AdminEntry;
import swe.d6.helper.Crypt;
import swe.d6.interfaces.RouteMapping;
import swe.d6.objects.Sessions;
import swe.d6.objects.Users;
import swe.d6.util.statics.RequestMethods;


@RouteMapping(method = RequestMethods.POST)
public class Login implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        String username = request.queryParams("username");
        String password = request.queryParams("password");
        if (username != null && password != null){
            AdminEntry admin = Users.getAsAdmin(username);
            if (admin != null && admin.isAdmin() && Crypt.verifyHash(password, admin.getPasswordHash()))
            {
                Sessions.addSessionId(admin);
                response.cookie("/","sessionId", admin.getSessionId(), -1, true, true);
            }
            else {
                response.status(401);
            }
            return "";
        }
        response.status(400);
        return "";
    }
}
