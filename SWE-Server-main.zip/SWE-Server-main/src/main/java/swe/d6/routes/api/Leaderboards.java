package swe.d6.routes.api;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.entries.LeaderboardEntry;
import swe.d6.entries.UserEntry;
import swe.d6.interfaces.RouteMapping;
import swe.d6.objects.Sessions;
import swe.d6.util.statics.RequestMethods;

import java.lang.reflect.Field;
import java.util.List;

import static swe.d6.util.statics.Statics.GSON;

@RouteMapping(method = RequestMethods.POST)
public class Leaderboards implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        String sessionId = request.queryParams("sessionId");
        UserEntry user = Sessions.getUserFromSessionId(sessionId);
        int userId = user == null ? -1 : user.getId();
        return GSON.toJson(new LeaderboardData(userId));
    }

    private static class LeaderboardData {
        private static final int WEEKLY_INDEX = 1;
        private static final int MONTHLY_INDEX = 2;

        private static final Field USER_ID;

        static {
            try {
                USER_ID = LeaderboardEntry.class.getDeclaredField("userId");
                USER_ID.setAccessible(true);
            } catch (NoSuchFieldException e) {
                throw new RuntimeException(e);
            }
        }

        private List<LeaderboardEntry> daily;
        private List<LeaderboardEntry> weekly;
        private List<LeaderboardEntry> monthly;

        public LeaderboardData(int userId) throws Exception {
            List<List<LeaderboardEntry>> data = swe.d6.objects.Leaderboards.getLeaderboardScoresApp(userId);
            /*if (userId > 0){
                LeaderboardEntry emptyEntry = new LeaderboardEntry();
                USER_ID.set(emptyEntry, userId);
                if (data.getFirst().stream().map(LeaderboardEntry::getUserId).noneMatch(integer -> integer == userId))
                    if (data.getFirst().size() > 15) data.getFirst().set(15, emptyEntry);
                    else data.getFirst().add(emptyEntry);
                if (data.get(WEEKLY_INDEX).stream().map(LeaderboardEntry::getUserId).noneMatch(integer -> integer == userId))
                    if (data.get(WEEKLY_INDEX).size() > 15) data.get(WEEKLY_INDEX).set(15, emptyEntry);
                    else data.get(WEEKLY_INDEX).add(emptyEntry);
                if (data.get(MONTHLY_INDEX).stream().map(LeaderboardEntry::getUserId).noneMatch(integer -> integer == userId))
                    if (data.get(MONTHLY_INDEX).size() > 15) data.get(MONTHLY_INDEX).set(15, emptyEntry);
                    else data.get(MONTHLY_INDEX).add(emptyEntry);
            }*/
            daily = data.getFirst();
            weekly = data.get(WEEKLY_INDEX);
            monthly = data.get(MONTHLY_INDEX);
        }
    }
}
