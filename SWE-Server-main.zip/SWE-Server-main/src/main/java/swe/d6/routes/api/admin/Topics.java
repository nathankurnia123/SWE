package swe.d6.routes.api.admin;

import spark.Request;
import spark.Response;
import swe.d6.interfaces.RouteMapping;

import java.util.Objects;

import static swe.d6.util.statics.Statics.*;

@RouteMapping
public class Topics extends BaseAdminRoute {
    @Override
    public Object handler(Request request, Response response) throws Exception {
        String query = request.queryParams("q");
        String page = request.queryParams("p");
        String all = request.queryParams("all");
        return GSON.toJson(Objects.equals(all, "1") ? swe.d6.objects.Topics.getTopics() : swe.d6.objects.Topics.searchTopics(query, page));
    }
}
