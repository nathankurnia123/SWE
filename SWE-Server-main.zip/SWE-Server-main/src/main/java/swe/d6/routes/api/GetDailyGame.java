package swe.d6.routes.api;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.interfaces.RouteMapping;
import swe.d6.objects.Questions;

import static swe.d6.util.statics.Statics.GSON;
/**
 * TODO: Implement functionality
 */
@RouteMapping
public class GetDailyGame implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        return GSON.toJson(Questions.getDailyGame());
    }
}
