package swe.d6.routes.fixes;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.interfaces.RouteMapping;

@RouteMapping(path = "/raw", name = "bWj98NYD")
public class WebGLFix implements Route {
    @Override
    public Object handle(Request request, Response response) throws Exception {
        return "webgl";
    }
}
