package swe.d6.routes.api;

import spark.Request;
import spark.Response;
import spark.Route;
import swe.d6.interfaces.RouteMapping;
import swe.d6.objects.Users;
import swe.d6.util.Validate;
import swe.d6.util.statics.RequestMethods;


@RouteMapping(method = RequestMethods.POST)
public class GetDiscriminator implements Route {

    @Override
    public Object handle(Request request, Response response) throws Exception {
        String username = request.queryParams("firstName");
        if (Validate.checkFirstName(username)){
            response.type("text/plain");
            return Users.getNextDiscriminator(username);
        }
        response.status(400);
        return "";
    }
}
