package swe.d6.interfaces;

import swe.d6.util.statics.RequestMethods;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface RouteMapping {
    RequestMethods method() default RequestMethods.GET;
    String name()  default "";
    String path() default "";
}