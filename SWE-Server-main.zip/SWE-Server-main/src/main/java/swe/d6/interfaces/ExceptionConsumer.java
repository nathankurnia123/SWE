package swe.d6.interfaces;

@FunctionalInterface
public interface ExceptionConsumer<T> {
    void accept(T t) throws Exception;
}
