package swe.d6.interfaces;

import java.sql.SQLException;

@FunctionalInterface
public interface ExceptionFunction<V, T> {
    V apply(T t) throws Exception;
}
