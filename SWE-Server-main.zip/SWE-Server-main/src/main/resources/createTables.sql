CREATE TABLE IF NOT EXISTS categories
(
    id   INTEGER NOT NULL PRIMARY KEY,
    name TEXT    NOT NULL UNIQUE COLLATE NOCASE
);

CREATE TABLE IF NOT EXISTS questions
(
    id             INTEGER NOT NULL PRIMARY KEY,
    category_id    INTEGER NOT NULL,
    level          INTEGER NOT NULL,

    question       TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    answer_a       TEXT    NOT NULL,
    answer_b       TEXT    NOT NULL,
    answer_c       TEXT    NOT NULL,
    answer_d       TEXT    NOT NULL,
    correct_answer INTEGER NOT NULL,

    FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE CASCADE,

    CHECK (level >= 1 AND level <= 15),
    CHECK (correct_answer >= 1 AND correct_answer <= 4)
);



CREATE TABLE IF NOT EXISTS game_of_the_day
(
    question_id INTEGER NOT NULL UNIQUE,

    CHECK (_ROWID_ >= 1 AND _ROWID_ <= 15),
    FOREIGN KEY (question_id) REFERENCES questions (id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS last_show
(
    question_id INTEGER NOT NULL UNIQUE,

    CHECK (_ROWID_ >= 1 AND _ROWID_ <= 15),
    FOREIGN KEY (question_id) REFERENCES questions (id) ON DELETE CASCADE
);



CREATE TABLE IF NOT EXISTS users
(
    id                INTEGER NOT NULL PRIMARY KEY,
    first_name        TEXT    NOT NULL COLLATE NOCASE,
    last_name         TEXT    NOT NULL,
    discriminator     INTEGER NOT NULL,
    birthday          NUMERIC NOT NULL,

    password_hash     TEXT    NOT NULL UNIQUE,

    security_question INTEGER NOT NULL,
    answer_hash       TEXT    NOT NULL UNIQUE,

    first_place       INTEGER NOT NULL DEFAULT 0,
    second_place      INTEGER NOT NULL DEFAULT 0,
    third_place       INTEGER NOT NULL DEFAULT 0,

    CHECK (security_question >= 1 AND security_question <= 5),
    CONSTRAINT unique_first_name_discriminator UNIQUE (first_name, discriminator)
);

CREATE TABLE IF NOT EXISTS admins
(
    user_id INTEGER NOT NULL PRIMARY KEY,

    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);



CREATE TABLE IF NOT EXISTS sessions
(
    id              TEXT    NOT NULL PRIMARY KEY,
    user_id         INTEGER NOT NULL,
    expiration_date NUMERIC NOT NULL,

    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS index_expiration_date ON sessions (expiration_date);



CREATE TABLE IF NOT EXISTS daily_scores
(
    user_id INTEGER NOT NULL PRIMARY KEY,
    score   INTEGER NOT NULL DEFAULT 0,

    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS weekly_scores
(
    user_id INTEGER NOT NULL PRIMARY KEY,
    score   INTEGER NOT NULL DEFAULT 0,

    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS monthly_scores
(
    user_id INTEGER NOT NULL PRIMARY KEY,
    score   INTEGER NOT NULL DEFAULT 0,

    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);



CREATE TABLE IF NOT EXISTS placements
(
    user_id INTEGER NOT NULL PRIMARY KEY,
    rank    INTEGER NOT NULL UNIQUE,

    FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS date(
    date TEXT NOT NULL,
    CHECK ( _ROWID_ == 1)
);