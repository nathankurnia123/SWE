<!--admin-->
import Interface from './interface.js';

class Users extends Interface {
    constructor() {
        super('users', '/api/securityQuestions');
        window.users = this;
    }

    setAddPopUp(formBuilder) {
        formBuilder
            .addTextField('firstName', 'Vorname', '', false,
                this.checkUserInput, this.checkFirstname, 'Vorname muss zwischen 3 und 14 Zeichen lang sein und darf kein "#" enthalten Nachname',
                async (value) => `Benutzername: ${value}#${await this.fetchAPI(`/api/getDiscriminator?firstName=${encodeURIComponent(value)}`, true)}`)
            .addTextField('lastName', 'Nachname', '', false,
                this.checkUserInput, this.checkLength, 'Nachname muss mindestens 3 Zeichen lang sein', '', 3)
            .addDateField('birthday', 'Geburtstag', '', false,
                this.checkUserInput, this.checkAge, 'Benutzer muss mindestens 15 Jahre alt sein')
            .addTextField('password', 'Passwort', '', false,
                this.checkUserInput, this.checkPassword, 'Passwort muss mindestens 8 Zeichen lang sein und mindestens einen Buchstaben und eine Zahl enthalten')
            .addSelectField('securityQuestion', 'Sicherheitsfrage', Object.entries(this.fetch).map((key) => ({
                    value: key[0], label: key[1]
                })), null, false,
                this.checkUserInput, (securityQuestion) => securityQuestion !== '', 'Es muss eine Sicherheitsfrage ausgewählt sein')
            .addTextField('securityQuestionAnswer', 'Sicherheitsfrage Antwort', '', false,
                this.checkUserInput, this.checkLength, 'Antwort muss mindestens 8 Zeichen lang sein', '', 8)
            .addNumberField('firstPlace', 'Goldmedaillen', '0', 0, 10000)
            .addNumberField('secondPlace', 'Silbermedaillen', '0', 0, 10000)
            .addNumberField('thirdPlace', 'Bronzemedaillen', '0', 0, 10000)
            .addSelectField('admin', 'Administrator', [
                    {value: '0', label: 'Nein'},
                    {value: '1', label: 'Ja'}
                ], '0', false,
                this.checkUserInput, (admin) => admin !== '', 'Es muss eine Option ausgewählt sein'
            );
    }

    fillEditEntryPopUp(editForm, entry) {
        editForm
            .addTextField('_id', 'ID', entry.id, true)
            .addTextField('firstName', 'Vorname', entry.firstName, true)
            .addTextField('lastName', 'Nachname', entry.lastName, false,
                this.checkUserInput, this.checkLength, 'Nachname muss mindestens 3 Zeichen lang sein', '', 3)
            .addDateField('birthday', 'Geburtstag', entry.birthday, false,
                this.checkUserInput, this.checkAge, 'Benutzer muss mindestens 15 Jahre alt sein')
            .addTextField('password', 'Passwort', '', false,
                this.checkUserInput, (value) => value === '' || this.checkPassword(value), 'Passwort muss mindestens 8 Zeichen lang sein und mindestens einen Buchstaben und eine Zahl enthalten')
            .addSelectField('securityQuestion', 'Sicherheitsfrage', Object.entries(this.fetch).map((key) => ({
                value: key[0], label: key[1]
            })), entry.securityQuestion, false)
            .addTextField('securityQuestionAnswer', 'Sicherheitsfrage Antwort', '', false,
                this.checkUserInput, (value, length) => value === '' || this.checkLength(value, length), 'Antwort muss mindestens 8 Zeichen lang sein', '', 8)
            .addNumberField('firstPlace', 'Goldmedaillen', entry.firstPlace, 0, 10000)
            .addNumberField('secondPlace', 'Silbermedaillen', entry.secondPlace, 0, 10000)
            .addNumberField('thirdPlace', 'Bronzemedaillen', entry.thirdPlace, 0, 10000)
            .addSelectField('admin', 'Administrator', [
                {value: 0, label: 'Nein'},
                {value: 1, label: 'Ja'}
            ], entry.admin ? 1 : 0, false);
    }

    getDeletePopUpDescription(){
        return 'Möchten Sie diesen Benutzer wirklich löschen?';
    }

    modifyEntry(entry) {
        return {
            id: entry.id,
            username: `${entry.firstName}#${entry.discriminator}`,
            birthday: this.convertDateFormat(entry.birthday),
            goldMedals: entry.firstPlace,
            silverMedals: entry.secondPlace,
            bronzeMedals: entry.thirdPlace,
            admin: entry.admin ? 'Ja' : 'Nein'
        }
    }

    addButtonsForTableEntries(row, entry){
        if (entry.id !== 1) super.addButtonsForTableEntries(row, entry)
        else row.insertCell();
    }

    convertDateFormat(dateString) {
        const parts = dateString.split('-');
        return parts[2] + '.' + parts[1] + '.' + parts[0];
    }
    checkFirstname(firstName) {
        return (
            firstName !== null &&
            firstName.length >= 3 &&
            firstName.length <= 14 &&
            !(firstName.trim().length === 0) &&
            !firstName.includes("#")
        );
    }

    checkPassword(password) {
        return (
            password !== null &&
            password.length > 7 &&
            !(password.trim().length === 0) &&
            /^(?=.*[a-zA-Z])(?=.*\d).+$/.test(password)
        );
    }

    checkAge(birthday) {
        const today = new Date();
        const birthDate = new Date(birthday);
        let age = today.getFullYear() - birthDate.getFullYear();
        const monthDifference = today.getMonth() - birthDate.getMonth();
        if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) age--;
        return age >= 15
    }
}

new Users();