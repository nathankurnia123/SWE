document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const form = document.getElementById("loginForm");
    const password = form.password.value;
    const errorMessage = document.getElementById("error-message");
    const formData = {
        //type: form.getAttribute("data-state"), // 'login' or 'register'
        username: form.username.value,
        password: password
    };
    // Perform form submission using fetch API
    fetch("/api/admin/login", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: objectToFormData(formData)
    }).then(response => {
        if (response.ok) window.location.pathname = '/admin/users';
        else {
            errorMessage.innerText = "Benutzername oder Passwort falsch";
            errorMessage.style.display = "block";
        }
    }).catch(error => {
        // Handle errors
        console.error(error);
    });
});

function objectToFormData(obj) {
    const formData = new URLSearchParams();

    for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
            formData.append(key, obj[key]);
        }
    }

    return formData.toString();
}