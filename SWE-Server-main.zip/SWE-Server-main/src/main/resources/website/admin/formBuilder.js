<!--admin-->
class FormBuilder {
    constructor(formId) {
        this.formId = formId;
        this.fields = [];
        this.buttons = [];
    }

    addTextField(inputId, labelText, initialValue = '', disabled = false, check, ...vars) {
        this.fields.push({
            inputElement: document.createElement('input'),
            type: 'text',
            inputId,
            labelText,
            initialValue,
            disabled,
            check,
            vars: {...vars}
        });
        return this; // Allow method chaining
    }

    addSelectField(selectId, labelText, options, defaultValue = null, disabled = false, check, ...vars) {
        if (!defaultValue) {
            // Add a placeholder option if no default value is provided
            options.unshift({value: '', label: 'Bitte Auswählen'});
        }

        this.fields.push({
            inputElement: document.createElement('select'),
            type: 'select',
            selectId,
            labelText,
            options,
            defaultValue,
            disabled,
            check,
            vars: {...vars}
        });
        return this; // Allow method chaining
    }

    addDateField(dateId, labelText, initialValue = '', disabled = false, check, ...vars) {
        this.fields.push({
            inputElement: document.createElement('input'),
            type: 'date',
            dateId,
            labelText,
            initialValue,
            disabled,
            check,
            vars: {...vars}
        });
        return this; // Allow method chaining
    }

    addNumberField(numberId, labelText, initialValue = '', min, max, disabled = false, check, ...vars) {
        this.fields.push({
            inputElement: document.createElement('input'),
            type: 'number',
            numberId,
            labelText,
            initialValue,
            min,
            max,
            disabled,
            check,
            vars: {...vars}
        });
        return this; // Allow method chaining
    }

    addButton(labelText, clickHandler, disabled = false, makeCheckButton = false) {
        this.buttons.push({
            buttonElement: document.createElement('button'),
            labelText,
            clickHandler,
            disabled,
            makeCheckButton
        });
        return this; // Allow method chaining
    }

    build() {
        const formElement = document.createElement('form');
        formElement.id = this.formId;

        this.fields.forEach(field => {
            const labelElement = document.createElement('label');
            labelElement.textContent = field.labelText;

            field.inputElement.id = field.inputId || field.selectId || field.dateId || field.numberId;
            field.inputElement.disabled = field.disabled;
            if (field.check !== undefined) field.inputElement.addEventListener('input', () => field.check(field.inputElement, ...Object.values(field.vars)))
            if (field.type === 'text') {
                field.inputElement.type = 'text';
                field.inputElement.value = field.initialValue;
            } else if (field.type === 'number') {
                field.inputElement.type = 'number';
                field.inputElement.value = field.initialValue;
                if (field.min !== undefined) field.inputElement.min = field.min;
                if (field.max !== undefined) field.inputElement.max = field.max;
                if (field.min !== undefined || field.max !== undefined) {
                    field.inputElement.addEventListener('input', () => {
                        if (field.inputElement.min !== '' && field.inputElement.value !== '' && parseInt(field.inputElement.min) > parseInt(field.inputElement.value)) field.inputElement.value = field.inputElement.min;
                        else if (field.inputElement.max !== '' && field.inputElement.value !== '' && parseInt(field.inputElement.max) < parseInt(field.inputElement.value)) field.inputElement.value = field.inputElement.max;
                    })
                }
            } else if (field.type === 'select') {
                field.options.forEach(option => {
                    const optionElement = document.createElement('option');
                    optionElement.value = option.value;
                    optionElement.textContent = option.label;
                    if (option.value === field.defaultValue) {
                        optionElement.selected = true;
                    }
                    field.inputElement.appendChild(optionElement);
                });
            } else if (field.type === 'date') {
                field.inputElement.type = 'date';
                field.inputElement.value = field.initialValue;
            }

            formElement.appendChild(labelElement);
            formElement.appendChild(field.inputElement);
        });

        this.buttons.forEach(button => {
            button.buttonElement.textContent = button.labelText;
            button.buttonElement.addEventListener('click', (event) => {
                event.preventDefault();
                let a = true;
                if (button.makeCheckButton)
                    for (let field of this.fields)
                        if (typeof field.check === 'function' && !field.check(field.inputElement, ...Object.values(field.vars)))
                            a = false;
                if (a) button.clickHandler(event);
            });
            formElement.appendChild(button.buttonElement);
        });

        return formElement;
    }
}

export default FormBuilder;

