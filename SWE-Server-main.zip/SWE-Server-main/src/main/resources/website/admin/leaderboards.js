<!--admin-->
import Interface from './interface.js';

class Leaderboards extends Interface{
    constructor() {
        super('leaderboards');
    }

    modifyEntry(entry) {
        return {
            id: entry.userId,
            username: `${entry.firstName}#${entry.discriminator}`,
            monthlyScore: entry.monthlyScore,
            weeklyScore: entry.weeklyScore,
            dailyScore: entry.dailyScore,
        }
    }

    addButtonsForTableEntries(row, entry){
        // Add "Edit" and "Delete" buttons to each row
        const buttonCell = row.insertCell();
        const resetButton = document.createElement("button");
        resetButton.className = "tableButton";
        resetButton.textContent = "Zurücksetzen";
        resetButton.addEventListener('click', () => this.deleteEntryPopUp(entry));
        buttonCell.appendChild(resetButton);
        buttonCell.style.textAlign = "right";
    }

    getDeletePopUpDescription(){
        return 'Möchten Sie die Punkte dieses Benutzers wirklich zurücksetzen?'
    }
}

new Leaderboards();