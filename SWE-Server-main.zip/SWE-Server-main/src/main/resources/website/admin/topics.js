<!--admin-->
import Interface from './interface.js';

class Topics extends Interface {
    constructor() {
        super('topics');
    }

    setAddPopUp(formBuilder) {
        formBuilder
            .addTextField('name', 'Thema', '', false,
                this.checkUserInput, this.checkLength, 'Thema muss mindestens 4 Zeichen lang sein', '', 4);
    }

    fillEditEntryPopUp(formBuilder, entry) {
        formBuilder
            .addTextField('_id', 'ID', entry.id, true)
            .addTextField('name', 'Thema', entry.name, false,
                this.checkUserInput, this.checkLength, 'Thema muss mindestens 4 Zeichen lang sein', '', 4);
    }

    getDeletePopUpDescription(){
        return 'Möchten Sie dieses Thema wirklich löschen?';
    }

    modifyEntry(entry) {
        return {
            id: entry.id,
            name: entry.name,
            numberOfQuestions: entry.numberOfQuestions
        }
    }

    errorHandler(event) {
        this.checkUserInput(event.target.parentElement.name, () => false, 'Thema mit diesem Namen bereits vorhanden');
    }
}
export default Topics;

new Topics();