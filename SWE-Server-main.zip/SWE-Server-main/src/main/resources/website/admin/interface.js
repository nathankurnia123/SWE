<!--admin-->
import FormBuilder from './formBuilder.js';

class Interface {
    constructor(name, fetch = undefined) {
        this.#initiateDeletePopUp()
        this.name = name;
        this.params = new URLSearchParams(window.location.search);
        if (fetch !== undefined) this.fetch = this.fetchAPI(fetch).then(json => {
            this.fetch = json;
        })
        Promise.all([this.#domContentLoaded(), this.fetchAPI()]).then(([, json]) => {
            if (this.getUrlParameter('p') && this.getUrlParameter('p') !== '1' && json.length === 0) {
                this.updateUrlParameter('p', '1')
                this.fetchAPI().then(j => {
                    this.json = j;
                    this.#fillTable();
                })
            } else {
                this.json = json;
                this.#fillTable();
            }
        });
    }

    #initiateDeletePopUp() {
        this.deletePopUp = document.createElement("form");
        this.deletePopUp.style.width = 'fit-content';
        const deleteTextElement = document.createElement("p");
        deleteTextElement.innerText = this.getDeletePopUpDescription();
        deleteTextElement.style.textAlign = 'center';
        const buttonContainer = document.createElement("div");
        buttonContainer.style.textAlign = 'center';
        const deleteButton = document.createElement("button");
        deleteButton.textContent = 'Ja';
        deleteButton.className = 'save-button';
        deleteButton.style.marginRight = '10px';
        deleteButton.addEventListener('click', (event) => {
            event.preventDefault();
            this.deleteEntry()
        });
        const cancelButton = document.createElement("button");
        cancelButton.textContent = 'Nein';
        cancelButton.className = 'cancel-button';
        cancelButton.addEventListener('click', event => {
            event.preventDefault();
            document.body.removeChild(document.getElementById('popupWrapper'));
            this.popUpWrapper.firstChild.remove();
        });
        this.deletePopUp.appendChild(deleteTextElement);
        this.deletePopUp.appendChild(buttonContainer);
        buttonContainer.appendChild(deleteButton);
        buttonContainer.appendChild(cancelButton);
    }

    getDeletePopUpDescription() {
        return 'Möchtest du diesen Eintrag wirklich löschen?';
    }

    #emptyTable() {
        this.tableBody.innerHTML = '';
        const row = this.tableBody.insertRow();
        const cell = row.insertCell();
        const style = cell.style;
        style.textAlign = 'center';
        cell.colSpan = this.tableBody.parentElement.rows[0].cells.length;
        cell.innerHTML = 'Kein Eintrag gefunden'
    }

    runCodeAfterPopUpCreation() {
    }

    #initializeAddButton() {
        const addForm = new FormBuilder('addForm');
        this.setAddPopUp(addForm);
        this.addForm = addForm
            .addButton('Hinzufügen', (event) => {
                const formData = this.#getFormData(this.addForm);
                fetch('/api/admin/add?type=' + this.name, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: this.#objectToFormData(formData)
                }).then(response => {
                    if (response.ok) {
                        document.body.removeChild(document.getElementById('popupWrapper'));
                        this.popUpWrapper.firstChild.remove();
                        this.#reloadTable();
                    } else {
                        this.errorHandler(event);
                    }
                }).catch(error => {
                    // Handle errors
                    console.error(error);
                });
            }, false, true)
            .addButton('Abbrechen', (event) => {
                document.body.removeChild(document.getElementById('popupWrapper'));
                this.popUpWrapper.firstChild.remove();
            })
            .build();
        this.popUpWrapper.appendChild(this.addForm);
        this.runCodeAfterPopUpCreation();
        document.body.appendChild(this.popUpWrapper);
    }

    #domContentLoaded() {
        return new Promise(resolve => {
            document.addEventListener('DOMContentLoaded', () => {
                this.tableBody = document.getElementById('tbody');

                this.addButton = document.getElementById('addButton');
                this.searchButton = document.getElementById('searchButton');
                this.searchBar = document.getElementById('searchBar');
                this.previousPageButton = document.getElementById('prev');
                this.nextPageButton = document.getElementById('next');

                this.searchBar.value = this.params.get('q');

                if (this.addButton) this.addButton.addEventListener('click', () => this.#initializeAddButton());
                this.searchBar.addEventListener('keyup', (event) => {
                    if (event.key === 'Enter' || this.searchBar.value === "") this.#search()
                });
                this.searchButton.addEventListener('click', (event) => {
                    event.preventDefault();
                    this.#search()
                });
                this.previousPageButton.addEventListener('click', () => this.#previousPage());
                this.nextPageButton.addEventListener('click', () => this.#nextPage());

                this.popUpWrapper = document.createElement('div');
                this.popUpWrapper.id = 'popupWrapper';
                resolve();
            });
        });
    }

    async fetchAPI(name = undefined, post = false) {
        try {
            const path = name === undefined ? `/api/admin/${this.name}?${this.params.toString()}` : name.at(0) === '/' ? name : `/api/admin/${name}`;
            const response = await fetch(path, {method: post ? 'POST' : 'GET'});
            if (!response.ok) console.error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error('Error:', error);
        }
    }

    #fillTable() {
        this.tableBody.innerHTML = '';
        if (this.json.length === 0) this.#emptyTable();
        else
            for (let entry of this.json) {
                const modifiedEntry = this.modifyEntry(entry);
                // Populate table_body with API data
                const row = this.tableBody.insertRow();

                Object.entries(modifiedEntry).forEach(([, value]) => {
                    const cell = row.insertCell();
                    cell.textContent = value.toString();
                });
                this.addButtonsForTableEntries(row, entry)
            }
    }

    addButtonsForTableEntries(row, entry) {
        // Add "Edit" and "Delete" buttons to each row
        const buttonCell = row.insertCell();
        const editButton = document.createElement("button");
        editButton.className = "tableButton";
        editButton.textContent = "Bearbeiten";
        editButton.addEventListener('click', () => this.editEntryPopUp(entry));
        buttonCell.appendChild(editButton);

        const deleteButton = document.createElement("button");
        deleteButton.className = "tableButton";
        deleteButton.textContent = "Löschen";
        deleteButton.addEventListener('click', () => this.deleteEntryPopUp(entry));
        buttonCell.appendChild(deleteButton);
        buttonCell.style.textAlign = "right";
    }

    editEntryPopUp(entry) {
        const editFormBuilder = new FormBuilder('editForm');
        this.fillEditEntryPopUp(editFormBuilder, entry);
        this.editForm = editFormBuilder
            .addButton('Änderungen speichern', (event) => {
                const formData = this.#objectToFormData(this.#getFormData(this.editForm));
                fetch('/api/admin/edit?type=' + this.name, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: formData
                }).then(response => {
                    if (response.ok) {
                        document.body.removeChild(document.getElementById('popupWrapper'));
                        this.popUpWrapper.firstChild.remove();
                        this.#reloadTable();
                    } else {
                        this.errorHandler(event);
                    }
                }).catch(error => {
                    // Handle errors
                    console.error(error);
                });
            }, false, true)
            .addButton('Abbrechen', () => {
                document.body.removeChild(document.getElementById('popupWrapper'));
                this.popUpWrapper.firstChild.remove();
            })
            .build();
        this.popUpWrapper.appendChild(this.editForm);
        this.runCodeAfterPopUpCreation();
        document.body.appendChild(this.popUpWrapper);
    }

    fillEditEntryPopUp(editForm, entry) {
    }

    deleteEntryPopUp(entry) {
        this.deletePopUp.data = entry;
        this.popUpWrapper.appendChild(this.deletePopUp);
        document.body.appendChild(this.popUpWrapper);
    }

    deleteEntry() {
        fetch('/api/admin/delete?type=' + this.name, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: this.#objectToFormData({
                id: this.deletePopUp.data.id !== undefined ? this.deletePopUp.data.id : this.deletePopUp.data.userId
            })
        }).then(response => {
            if (response.ok) {
                document.body.removeChild(document.getElementById('popupWrapper'));
                this.popUpWrapper.firstChild.remove();
                this.#reloadTable();
            } else {
                //TODO: handle code 400
            }
        }).catch(error => {
            // Handle errors
            console.error(error);
        });
    }

    errorHandler(event){

    }

    modifyEntry(entry) {
        return entry;
    }

    setAddPopUp(formBuilder) {
    }

    #search() {
        this.updateUrlParameter('q', this.searchBar.value);
        this.updateUrlParameter('p', '1');
        this.fetchAPI().then(json => {
            this.json = json;
            this.#fillTable();
        });
    }

    #previousPage() {
        const page = parseInt(this.getUrlParameter('p'));
        if (!isNaN(page) && page > 1) {
            this.updateUrlParameter('p', page - 1);
            this.fetchAPI().then(json => {
                this.json = json;
                this.#fillTable();
            });
        } else if (this.json.length === 0) this.#emptyTable();
    }

    #nextPage() {
        const page = parseInt(this.getUrlParameter('p'));
        this.updateUrlParameter('p', isNaN(page) ? 2 : page + 1);
        this.fetchAPI().then(json => {
            if (json.length === 0) {
                this.#previousPage();
                return;
            }
            this.json = json;
            this.#fillTable();
        });
    }

    #reloadTable() {
        this.fetchAPI().then(json => {
            this.json = json;
            if (json.length === 0) {
                this.#previousPage();
            } else this.#fillTable();
        });
    }

    getUrlParameter(key) {
        return this.params.get(key);
    }

    updateUrlParameter(key, value) {
        this.params.set(key, value);
        window.history.replaceState({}, '', `${location.pathname}?${this.params}`);
    }


    #getFormData(form) {
        const formData = {};

        // Iterate over form elements
        for (let i = 0; i < form.elements.length; i++) {
            const element = form.elements[i];

            // Check if the element has an ID and a value (to exclude buttons)
            if (element.id && element.value !== undefined) {
                formData[element.id] = element.value;
            }
        }

        return formData;
    }

    #objectToFormData(obj) {
        const formData = new URLSearchParams();

        for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
                formData.append(key, obj[key]);
            }
        }

        return formData.toString();
    }

    checkUserInput(field, functionToCheckInputOfField, errorMessage, onPass = undefined, ...additionalParams) {
        let errorContainer = field.nextElementSibling;
        // Check if an error container already exists
        if (!errorContainer || !errorContainer.classList.contains('error-message')) {
            // If not, create a new one
            errorContainer = document.createElement('div');
            errorContainer.className = 'error-message';
            field.parentNode.insertBefore(errorContainer, field.nextSibling);
        }
        if (!functionToCheckInputOfField(field.value, ...additionalParams)) {
            errorContainer.textContent = errorMessage;
            return false;
        } else {
            switch (typeof onPass) {
                case "string":
                    errorContainer.textContent = onPass;
                    break;
                case "function":
                    Promise.resolve(onPass(field.value)).then(value => errorContainer.textContent = value);
                    break;
                default:
                    errorContainer.textContent = '';
            }
            return true;
        }
    }

    checkLength(text, length) {
        return (
            text !== null &&
            text.length >= length &&
            !(text.trim().length === 0)
        );
    }
}

export default Interface;