<!--admin-->
import Interface from './interface.js';

class Questions extends Interface{
    constructor() {
        super('questions', 'topics?all=1');
        window.questiones = this;
    }

    AToD = ['A', 'B', 'C', 'D'];

    levels = ['50€', '100€', '200€', '300€', '500€', '1.000€', '2.000€', '4.000€', '8.000€', '16.000€', '32.000€', '64.000€', '125.000€', '500.000€', '1.000.000'];

    setAddPopUp(formBuilder) {
        formBuilder
            .addTextField('question', 'Frage', '', false,
                this.checkUserInput, this.checkLength, 'Frage muss mindestens 4 Zeichen lang sein', '', 4)
            .addTextField('answerA', 'Antwort A', '', false,
                this.checkUserInput, this.checkLength, 'Antwort muss mindestens 4 Zeichen lang sein', '', 4)
            .addTextField('answerB', 'Antwort B', '', false,
                this.checkUserInput, this.checkLength, 'Antwort muss mindestens 4 Zeichen lang sein', '', 4)
            .addTextField('answerC', 'Antwort C', '', false,
                this.checkUserInput, this.checkLength, 'Antwort muss mindestens 4 Zeichen lang sein', '', 4)
            .addTextField('answerD', 'Antwort D', '', false,
                this.checkUserInput, this.checkLength, 'Antwort muss mindestens 4 Zeichen lang sein', '', 4)
            .addSelectField('correctAnswer', 'Richtige Antwort', [
                { value: 1, label: 'Antwort A' },
                { value: 2, label: 'Antwort B' },
                { value: 3, label: 'Antwort C' },
                { value: 4, label: 'Antwort D' }
            ], null,false, this.checkUserInput, (value) => value !== '', 'Es muss eine Option ausgewählt sein')
            .addSelectField('level', 'Gewinnstufe', this.levels.map((level, index) => ({
                value: (index + 1),
                label: level
            })), null,false, this.checkUserInput, (value) => value !== '', 'Es muss eine Option ausgewählt sein')
            .addSelectField('topic', 'Themenbereich', this.fetch.map((item) => ({
                value: item.id,
                label: item.name
            })), null,false, this.checkUserInput, (value) => value !== '', 'Es muss eine Option ausgewählt sein');
    }

    fillEditEntryPopUp(formBuilder, entry) {
        formBuilder
            .addTextField('_id', 'ID', entry.id, true)
            .addTextField('question', 'Frage', entry.question, false,
                this.checkUserInput, this.checkLength, 'Frage muss mindestens 4 Zeichen lang sein', '', 4)
            .addTextField('answerA', 'Antwort A', entry.answerA, false,
                this.checkUserInput, this.checkLength, 'Antwort muss mindestens 4 Zeichen lang sein', '', 4)
            .addTextField('answerB', 'Antwort B', entry.answerB, false,
                this.checkUserInput, this.checkLength, 'Antwort muss mindestens 4 Zeichen lang sein', '', 4)
            .addTextField('answerC', 'Antwort C', entry.answerC, false,
                this.checkUserInput, this.checkLength, 'Antwort muss mindestens 4 Zeichen lang sein', '', 4)
            .addTextField('answerD', 'Antwort D', entry.answerD, false,
                this.checkUserInput, this.checkLength, 'Antwort muss mindestens 4 Zeichen lang sein', '', 4)
            .addSelectField('correctAnswer', 'Richtige Antwort', [
                { value: 1, label: 'Antwort A' },
                { value: 2, label: 'Antwort B' },
                { value: 3, label: 'Antwort C' },
                { value: 4, label: 'Antwort D' }
            ], entry.correctAnswer)
            .addSelectField('level', 'Gewinnstufe', this.levels.map((level, index) => ({
                value: (index + 1),
                label: level
            })), entry.level)
            .addSelectField('topic', 'Themenbereich', this.fetch.map((item) => ({
                value: item.id,
                label: item.name
            })), entry.categoryId);
    }

    getDeletePopUpDescription(){
        return 'Möchten Sie diese Frage wirklich löschen?';
    }

    modifyEntry(entry) {
        return {
            id: entry.id,
            question: entry.question,
            answerA: entry.answerA,
            answerB: entry.answerB,
            answerC: entry.answerC,
            answerD: entry.answerD,
            correctAnswer: this.AToD[entry.correctAnswer - 1],
            level: this.levels[entry.level - 1],
            topic: entry.topic
        }
    }

    errorHandler(event) {
        this.checkUserInput(event.target.parentElement.question, () => false, 'Frage mit dieser Fragestellung bereits vorhanden');
    }
}

new Questions();