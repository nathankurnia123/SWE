ATTACH DATABASE 'defaults.db' AS defaults;

INSERT INTO categories
SELECT *
FROM defaults.categories;

INSERT INTO questions
SELECT *
FROM defaults.questions;