package Bank;

import java.util.Objects;

public abstract class Transaction implements CalculateBill{
    protected String date;
    protected double amount;
    protected String description;
    protected boolean status = true;

    /**
     *
     * @param amount amount of the transaction
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     *
     * @return amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     *
     * @param date date of the transaction
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     *
     * @return date of the transaction
     */
    public String getDate() {
        return date;
    }

    /**
     *
     * @param description description of the transaction
     *
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     *
     * @return description
     */
    public String getDescription() {
        return description;
    }

    /**
     *
     * @param datum date of the transaction
     * @param Betrag amount of the transaction
     * @param desc description of the transaction
     */
    Transaction(String datum,double Betrag, String desc){
        setDate(datum);
        setAmount(Betrag);
        setDescription(desc);
    }

    /**
     * function to write attributes of the class
     * @return a String of attributes
     */
    @Override
    public String toString(){
        if(!status)
            return "Transaction is failed.\n";
        else
            return " Date of payment: " +date+
                    "\n Amount of Transaction: " + calculate() +
                    "\n Description: " +description;
    }

    /**
     * function to compare current Variable and an Object
     * @param obj other objekt to compare with
     * @return whether the result of compare true or false
     */
    @Override
    public boolean equals(Object obj){
        if(this==obj)
            return true;
        if(obj instanceof Transaction transaction){
            return Objects.equals(this.date, transaction.date) && Double.compare(this.amount, transaction.amount) == 0
                    && Objects.equals(this.description, transaction.description);
        }else
            return false;
    }
}