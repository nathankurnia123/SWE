package Bank;


public class Payment extends Transaction{

    private double incomingInterest;        //Attribute für Zinsen der Einzahluing
    private double outgoingInterest;        //Attribute für Zinsen der Auszahlung



    /*
     *
     * Getter und Setter for Attributes
     * um jede Attributes von außen zuzugriffen bzw, um zu setzen oder zu kriegen
     * set = zu setzen, get = zu kriegen
     *
     **/

    /**
     *
     * @return incomingInterest
     */
    public double getIncomingInterest() {
        return incomingInterest;
    }

    /**
     *
     * @param incomingInterest incoming interest of the payment
     *
     */
    public void setIncomingInterest(double incomingInterest) {
        if(incomingInterest < 0 || incomingInterest > 1) {                                                          //Überprüfung die Zahl von Zinsen der Einzahlung
            System.out.println("Payment error, value of incoming interest must be in percent between 0 and 1!");    //Error Message
            status = false;
        }else {
            this.incomingInterest = incomingInterest;
            status=true;
        }
    }

    /**
     *
     * @return outgoingInterest
     */
    public double getOutgoingInterest() {
        return outgoingInterest;
    }

    /**
     *
     * @param outgoingInterest outgoing interest of the payment
     */
    public void setOutgoingInterest(double outgoingInterest) {
        if(outgoingInterest < 0 || outgoingInterest > 1) {                                                       //Überprüfung die Zahl von Zinsen der Auszahlung
            System.out.println("Payment error, value of outgoing interest must be in percent between 0 and 1!"); //Error Message
            status=false;
        }else {
            this.outgoingInterest = outgoingInterest;
            status=true;
        }
    }
    /**
     * constructor of the class
     * @param date1 date of the Payment
     * @param amount1 amount of the Payment
     * @param desc description of the Payment
     */

    public Payment (String date1 , double amount1, String desc){
        super(date1,amount1,desc);
    }
    public Payment (String date2, double amount2, String desc1, double in, double out){
        this(date2,amount2,desc1);
        setIncomingInterest(in);
        setOutgoingInterest(out);
    }

    /**
     *
     * @param other other object to copy
     */
    public Payment (Payment other){
        this(other.date,other.amount, other.description, other.incomingInterest, other.outgoingInterest);
    }



    /**
     *
     * @return amount of the current Variable
     */
    @Override
    public double calculate(){
        double amount=getAmount();
        double zinsen=0;
        if(amount>0){
            zinsen=getIncomingInterest();
            return amount-(amount*zinsen);
        }else{
            zinsen=getOutgoingInterest();
            return amount+(amount*zinsen);
        }
    }

    /**
     * function to write attributes of the class
     * @return a String of attributes
     */
    @Override
    public String toString(){
        if(!status)
            return super.toString();
        else
            return super.toString()+
                    "\n Incoming interest: " +incomingInterest+
                    "\n Outgoing interest: "+outgoingInterest+"\n";
    }

    /**
     * function to compare current Variable and an Object
     * @param obj other objekt to compare with
     * @return whether the result of compare true or false
     */
    @Override
    public boolean equals (Object obj){
        if(this==obj)
            return true;
        if(obj instanceof Payment payment){
            if(super.equals(payment) && Double.compare( this.incomingInterest, payment.incomingInterest)==0 && Double.compare(this.outgoingInterest ,payment.outgoingInterest)==0)
                return true;
            else
                return false;
        }else
            return false;
    }

}