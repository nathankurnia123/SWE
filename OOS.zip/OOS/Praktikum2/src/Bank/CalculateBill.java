package Bank;

// interface ist eine Klasse, die nur abstrakte Methoden enthält
// und keine Attribute hat

public interface CalculateBill {
    public double calculate();
}