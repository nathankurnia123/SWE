/**
 * @author Muhammad Mulya Salam
 */

import Bank.Payment;
import Bank.Transfer;
import Bank.Transaction;
public class Main {
    public static void main(String[] args) {
      Transfer transfer1 = new Transfer("02.08.2022",750,"this is Transfer","Sender is parent","recipient me");
        Transfer transfer1copy = new Transfer(transfer1);

        System.out.println(transfer1.equals(transfer1copy));
        transfer1copy.setAmount(100);


        System.out.println(transfer1.toString());
        System.out.println(transfer1copy.toString());

        transfer1.setAmount(-400);
        System.out.println(transfer1.toString());



        Payment payment1 = new Payment("01.12.2023",1200,"this is deposit",0.15,0.1);
        Payment payment1copy = new Payment(payment1);
        System.out.println(payment1.equals(payment1copy));

        payment1.setAmount(1000);
        payment1copy.setAmount(-1000);
        System.out.println(payment1.toString());
        System.out.println(payment1copy.toString());


        System.out.println(payment1.calculate());
        System.out.println(payment1copy.calculate());
        System.out.println(transfer1.calculate());


        }
}