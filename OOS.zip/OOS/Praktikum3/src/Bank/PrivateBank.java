package Bank;

import Bank.exceptions.*;
import java.util.*;


public class PrivateBank implements Bank{
    private String name;
    private double incomingInterest;
    private double OutgoingInterest;
    private Map<String, List<Transaction>> accountsToTransactions = new HashMap<>();

    private boolean status=true;

    /**
     *
     * @param name name of the bank
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return name of the bank
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param incomingInterest incoming interest of the bank
     * */
    public void setIncomingInterest(double incomingInterest) {
        if(incomingInterest > 0 && incomingInterest < 1) {
            this.incomingInterest = incomingInterest;
        }else status = false;
    }

    /**
     *
     * @return incoming interest of the bank
     */
    public double getIncomingInterest() {
        return incomingInterest;
    }

    /**
     *
     * @param outgoingInterest outgoing interest of the bank
     */
    public void setOutgoingInterest(double outgoingInterest) {
        if(outgoingInterest > 0 && outgoingInterest < 1) {
            OutgoingInterest = outgoingInterest;
        }else status = false;
    }

    /**
     *
     * @return outgoing interest of the bank
     */
    public double getOutgoingInterest() {
        return OutgoingInterest;
    }

    /**
     *
     * @param name name of the bank
     * @param incomingInterest incoming interest of the bank
     * @param outgoingInterest outgoing interest of the bank
     */
    public PrivateBank(String name, double incomingInterest, double outgoingInterest){
        this.name=name;
        setIncomingInterest(incomingInterest);
        setOutgoingInterest(outgoingInterest);
    }

    /**
     *
     * @param other other object of the class
     */
    public PrivateBank(PrivateBank other){
        this(other.name,other.incomingInterest,other.OutgoingInterest);
    }

    /**
     * function to write attributes of the class
     * @return a String of attributes
     */
    @Override
    public String toString(){
        String res = "Name :"+this.name+
                "\nIncoming interest: "+this.incomingInterest+
                "\nOutgoing interest: "+this.OutgoingInterest;
        Set<String> keys = accountsToTransactions.keySet();
        for(String key:keys){
            res+="\n"+key+"=> \n";
            List<Transaction> Lists = accountsToTransactions.get(key);
            res+="[\n";
            for(Transaction transaction:Lists)
                res+=transaction+"\n";
            res+="]\n";
        }
        return res;
    }

    /**
     * function to compare current Variable and an Object
     * @param obj other objekt to compare with
     * @return whether the result of compare true or false
     */
    @Override
    public boolean equals(Object obj){
        if(this==obj)
            return true;
        if(obj instanceof PrivateBank privateBank){
            return Objects.equals(this.name, privateBank.name) && this.incomingInterest == privateBank.incomingInterest && this.OutgoingInterest == privateBank.OutgoingInterest &&this.accountsToTransactions.equals(privateBank.accountsToTransactions);
        }else
            return false;
    }

    /**
     *
     * @param account the account to be added
     * @throws AccountAlreadyExistsException if the account already exists
     */
    @Override
    public void createAccount(String account) throws AccountAlreadyExistsException{
        if(accountsToTransactions.containsKey(account))
            throw new AccountAlreadyExistsException("account with the name "+account+" in the bank"+name+" already exists!");
        else {
            accountsToTransactions.put(account, List.of());
            System.out.println("account with the name " + account + " has succesfully created in the bank " + name);
        }
    }

    /**
     *
     * @param account      the account to be added
     * @param transactions a list of already existing transactions which should be added to the newly created account
     * @throws AccountAlreadyExistsException if the account already exists
     * @throws TransactionAlreadyExistException if the transaction already exists
     * @throws TransactionAttributeException if the validation check for certain attributes fail
     */
    @Override
    public void createAccount(String account, List<Transaction> transactions)
            throws AccountAlreadyExistsException,TransactionAlreadyExistException,TransactionAttributeException {
        if (accountsToTransactions.containsKey(account)) {
            throw new AccountAlreadyExistsException("account with the name " + account + " in the bank" + name + " already exists!");
        } else {
            for (Transaction tr : transactions) {
                if (accountsToTransactions.containsKey(account) && accountsToTransactions.get(account).contains(tr)) {
                    throw new TransactionAlreadyExistException("duplicate transaction can not be added to the account!");
                } else {
                    if (tr instanceof Payment payment) {
                        setIncomingInterest(payment.getIncomingInterest());
                        setOutgoingInterest(payment.getOutgoingInterest());
                        if (!status) {
                            throw new TransactionAttributeException("Transaction attribute fails!");
                        }
                    }

                }
            }
            accountsToTransactions.put(account, transactions);
            System.out.println("account with the name " + account + " and its transaction has succesfully created in the bank " + name);
        }
    }

    /**
     *
     * @param account     the account to which the transaction is added
     * @param transaction the transaction which should be added to the specified account
     * @throws TransactionAlreadyExistException if the transaction already exists
     * @throws AccountDoesNotExistException    if the specified account does not exist
     * @throws TransactionAttributeException    if the validation check for certain attributes fail
     */
    @Override
    public void addTransaction(String account, Transaction transaction)
            throws TransactionAlreadyExistException, AccountDoesNotExistException, TransactionAttributeException{
        if(!accountsToTransactions.containsKey(account)){
            throw new AccountDoesNotExistException("account with the name "+account+" in the bank"+name+" does not exist!");
        }else {
            if(accountsToTransactions.get(account).contains(transaction)){
                throw new TransactionAlreadyExistException("this transaction is already exist in the account "+account);
            }else{
                if(transaction instanceof Payment payment) {
                    setIncomingInterest(payment.getIncomingInterest());
                    setOutgoingInterest(payment.getOutgoingInterest());
                    if(!status){
                        throw new TransactionAttributeException("Transaction attribute fails!");

                    }
                }
                List<Transaction> Lists = new ArrayList<>(accountsToTransactions.get(account));
                Lists.add(transaction);
                accountsToTransactions.put(account,Lists);
                System.out.println("Transaction successfully added");

            }
        }
    }


    /**
     *
     * @param account     the account from which the transaction is removed
     * @param transaction the transaction which is removed from the specified account
     * @throws AccountDoesNotExistException    if the specified account does not exist
     * @throws TransactionDoesNotExistException if the transaction cannot be found
     */
    @Override
    public void removeTransaction(String account, Transaction transaction)
            throws AccountDoesNotExistException, TransactionDoesNotExistException{
        if(!accountsToTransactions.containsKey(account)){
            throw new AccountDoesNotExistException("account with the name "+account+" in the bank"+name+" does not exist!");
        }else {
            if(!accountsToTransactions.get(account).contains(transaction)){
                throw new TransactionDoesNotExistException("this transaction does not exist in the account "+account);
            }else{
                accountsToTransactions.get(account).remove(transaction);
                System.out.println("Transaction successfully removed");
            }
        }
    }

    /**
     *
     * @param account     the account from which the transaction is checked
     * @param transaction the transaction to search/look for
     * @return whether the transaction exists or not
     */
    @Override
    public boolean containsTransaction(String account, Transaction transaction){
        if(accountsToTransactions.containsKey(account)){
            if(accountsToTransactions.get(account).contains(transaction))
                return true;
            else
                return false;
        }else
            return false;
    }

    /**
     *
     * @param account the selected account
     * @return the current account balance
     */
    @Override

    public double getAccountBalance(String account){
        double balance=0;
        List<Transaction> Lists = accountsToTransactions.get(account);
        for(Transaction tr:Lists){
            balance += tr.calculate();
        }
        return balance;
    }

    /**
     *
     * @param account the selected account
     * @return the list of all transactions for the specified account
     */
    @Override
    public List<Transaction> getTransactions(String account){
        return accountsToTransactions.get(account);
    }

    /**
     *
     * @param account the selected account
     * @param asc     selects if the transaction list is sorted in ascending or descending order
     * @return the sorted list of all transactions for the specified account
     */
    @Override
    public List<Transaction> getTransactionsSorted(String account, boolean asc){
        List<Transaction> sorted = new ArrayList<>(accountsToTransactions.get(account));
        if(asc)
            sorted.sort(Comparator.comparing(Transaction::calculate));
        else
            sorted.sort(Comparator.comparing(Transaction::calculate).reversed());
        return sorted;
    }

    /**
     *
     * @param account  the selected account
     * @param positive selects if positive or negative transactions are listed
     * @return the list of either positive or negative transactions (-> calculated amounts)
     */
    @Override
    public List<Transaction> getTransactionsByType(String account, boolean positive){
        List<Transaction> type = new ArrayList<>();
        List<Transaction> Lists = accountsToTransactions.get(account);
        for(Transaction tr : Lists){
            if(positive && tr.calculate()>=0){
                type.add(tr);
            }else if(!positive && tr.calculate()<0){
                type.add(tr);
            }
        }
        return type;
    }
}
