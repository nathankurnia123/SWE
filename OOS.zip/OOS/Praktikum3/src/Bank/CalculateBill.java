package Bank;

// interface ist eine Klasse, die nur abstrakte Methoden enthält
// und keine Attribute hat

public interface CalculateBill {
    /**
     *
     * @return amount of the transaction
     */
    public double calculate();
}