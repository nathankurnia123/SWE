package Bank.exceptions;

public class TransactionAttributeException extends Exception{
    public TransactionAttributeException(String message){
        super(message);
    }
}