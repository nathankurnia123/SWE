package Bank;

public class IncomingTransfer extends Transfer{

    /**
     *
     * @param date date of the transaction
     * @param desc description of the transaction
     * @param amount    amount of the transaction
     */
    public IncomingTransfer(String date,  double amount,String desc){
        super(date,amount,desc);
    }

    /**
     *
     * @param date date of the transaction
     * @param amount   amount of the transaction
     * @param desc description of the transaction
     * @param send sender of the transaction
     * @param rec recipient of the transaction
     */
    public IncomingTransfer(String date, double amount, String desc, String send, String rec){
        super(date,amount,desc,send,rec);
    }

    public IncomingTransfer(IncomingTransfer other){
        super(other);
    }

    /**
     *
     * @return amount
     */
    @Override
    public double calculate(){
        return super.calculate();
    }
}