public class PrivateBankTest {
}
