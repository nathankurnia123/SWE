package bank;

public interface CalculateBill {
    public double calculate();
}