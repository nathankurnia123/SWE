package bank;

public class Payment {
}
