package bank;

public class IncomingTransfer {
}
