package bank;

public class Transaction {
}
