package bank;

public class PrivateBank {
}
