package bank;

public class Transfer {
}
