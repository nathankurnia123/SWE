package bank;

public class OutgoingTransfer {
}
