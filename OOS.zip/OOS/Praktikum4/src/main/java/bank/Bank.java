package bank;

public class Bank {
}
