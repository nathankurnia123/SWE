package bank.exceptions;

public class IncomingException {
}
