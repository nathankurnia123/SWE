package bank.exceptions;

public class OutgoingException {
}
