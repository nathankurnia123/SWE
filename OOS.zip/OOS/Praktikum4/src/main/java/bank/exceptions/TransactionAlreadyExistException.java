package bank.exceptions;

public class TransactionAlreadyExistException {
}
