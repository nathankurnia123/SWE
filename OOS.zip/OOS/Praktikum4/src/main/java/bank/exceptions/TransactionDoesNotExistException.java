package bank.exceptions;

public class TransactionDoesNotExistException {
}
