package bank.exceptions;

public class TransactionAttributeException {
}
