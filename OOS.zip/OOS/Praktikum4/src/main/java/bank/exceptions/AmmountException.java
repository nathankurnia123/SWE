package bank.exceptions;

public class AmmountException {
}
