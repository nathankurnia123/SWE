import numpy as np

class Perceptron:

    def __init__(self):
        # Initialize the synaptic weights with random values
        self.synaptic_weights = 2 * np.random.random((3, 1)) - 1
        print(f"Initial synaptic weights: \n{self.synaptic_weights}")

    # Sigmoid function
    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    # Derivative of sigmoid function
    def sigmoid_derivative(self, x):
        return x * (1 - x)

    # Training loop
    def train(self, inputs, targets, iterations):
        for iteration in range(iterations):
            # Forward pass: calculate the output
            outputs = self.think(inputs)

            # Calculate the error
            error = targets - outputs

            # Backpropagation: calculate adjustments
            adjustments = np.dot(inputs.T, error * self.sigmoid_derivative(outputs))

            # Adjust the synaptic weights
            self.synaptic_weights += adjustments

        print(f"Synaptic weights after training: \n{self.synaptic_weights}")

    # One calculation step of the perceptron
    def think(self, inputs):
        return self.sigmoid(np.dot(inputs, self.synaptic_weights))

if __name__ == "__main__":
    # Create instance of Perceptron
    p = Perceptron()

    # Training data: 4 examples with 3 input values each
    training_inputs = np.array([[0, 0, 1],
                                [1, 1, 1],
                                [1, 0, 0],
                                [0, 1, 1]])

    # Target outputs
    training_outputs = np.array([[0, 1, 1, 0]]).T

    # Train the perceptron
    p.train(training_inputs, training_outputs, 10000)

    # Get user inputs
    I1 = float(input("Enter value for I1: "))
    I2 = float(input("Enter value for I2: "))
    I3 = float(input("Enter value for I3: "))

    user_inputs = np.array([I1, I2, I3])

    # Perceptron's prediction
    output = p.think(user_inputs)

    print(f"Perceptron's belief: {output}")
