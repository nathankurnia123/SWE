import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

class FeedForwardNetwork:
    def __init__(self, input_nodes=784, hidden_nodes=200, output_nodes=10, learning_rate=0.1):
        self.input_nodes = input_nodes
        self.hidden_nodes = hidden_nodes
        self.output_nodes = output_nodes
        self.learning_rate = learning_rate

        # Initialize weight matrices with random values
        self.W_ih = np.random.rand(self.hidden_nodes, self.input_nodes) - 0.5
        self.W_ho = np.random.rand(self.output_nodes, self.hidden_nodes) - 0.5

    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def sigmoid_derivative(self, x): #x here as S(x)->(result from sigmoid)
        return x * (1 - x)

    def think(self, inputs):
        # Forward pass
        hidden_inputs = np.dot(self.W_ih, inputs)
        hidden_outputs = self.sigmoid(hidden_inputs)

        final_inputs = np.dot(self.W_ho, hidden_outputs)
        final_outputs = self.sigmoid(final_inputs)

        return final_outputs

    def train(self, inputs_list, targets_list, iterations):
        for _ in range(iterations):
            for inputs, targets in zip(inputs_list, targets_list):
                # Convert inputs and targets to 2D arrays
                inputs = np.array(inputs, ndmin=2).T
                targets = np.array(targets, ndmin=2).T

                # Forward pass
                hidden_inputs = np.dot(self.W_ih, inputs)
                hidden_outputs = self.sigmoid(hidden_inputs)

                final_inputs = np.dot(self.W_ho, hidden_outputs)
                final_outputs = self.sigmoid(final_inputs)

                # Calculate errors
                output_errors = targets - final_outputs
                hidden_errors = np.dot(self.W_ho.T, output_errors)

                # Backward pass
                self.W_ho += self.learning_rate * np.dot((output_errors * self.sigmoid_derivative(final_outputs)), hidden_outputs.T)
                self.W_ih += self.learning_rate * np.dot((hidden_errors * self.sigmoid_derivative(hidden_outputs)), inputs.T)

    def test(self, test_inputs, test_targets):
        scorecard = []
        for inputs, target in zip(test_inputs, test_targets):
            outputs = self.think(inputs)
            label = np.argmax(outputs)
            correct_label = np.argmax(target)
            scorecard.append(1 if label == correct_label else 0)
        return scorecard

if __name__ == "__main__":
    # Load and preprocess the data
    train_data = pd.read_csv('mnist_train_100.csv', header=None).values
    test_data = pd.read_csv('mnist_test_10.csv', header=None).values

    # Normalize input values and convert labels to target arrays
    train_inputs = (train_data[:, 1:] / 255.0 * 0.98) + 0.01
    train_targets = np.zeros((train_data.shape[0], 10)) + 0.01
    for i, label in enumerate(train_data[:, 0]):
        train_targets[i][label] = 0.99

    test_inputs = (test_data[:, 1:] / 255.0 * 0.98) + 0.01
    test_targets = np.zeros((test_data.shape[0], 10)) + 0.01
    for i, label in enumerate(test_data[:, 0]):
        test_targets[i][label] = 0.99

    # Create network instance and train it
    ffn = FeedForwardNetwork()
    ffn.train(train_inputs, train_targets, iterations=100)

    # Test the network
    scorecard = ffn.test(test_inputs, test_targets)
    performance = sum(scorecard) / len(scorecard) * 100
    print(f"Performance: {performance}%")

    # Plot an example test image
    image_array = test_data[0, 1:].reshape((28, 28))
    plt.imshow(image_array, cmap='Greys', interpolation='None')
    plt.show()
