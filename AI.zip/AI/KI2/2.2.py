import random

class EightQueensGA:
    def __init__(self, population_size=100):
        self.population_size = population_size
        self.population = self.initialize_population()

    def initialize_population(self):
        population = []
        for _ in range(self.population_size):
            individual = [random.randint(0, 7) for _ in range(8)]  # Randomly initialize queens' positions
            population.append(individual)
        return population

    def calculate_conflicts(self, individual):
        conflicts = 0
        for i in range(len(individual)):
            for j in range(i + 1, len(individual)):
                if individual[i] == individual[j] or abs(individual[i] - individual[j]) == abs(i - j):
                    conflicts += 1
        return conflicts  # Return total number of conflicts

    def fitness(self, individual):
        conflicts = self.calculate_conflicts(individual)
        return 28 - conflicts  # Maximum fitness is 28 (no conflicts)

    def selection(self):
        return sorted(self.population, key=self.fitness, reverse=True)[:10]  # Select top 10 individuals based on fitness

    def crossover(self, parent1, parent2):
        crossover_point = random.randint(1, 7)  # Random crossover point
        child1 = parent1[:crossover_point] + parent2[crossover_point:]
        child2 = parent2[:crossover_point] + parent1[crossover_point:]
        return child1, child2

    def mutation(self, individual):
        mutated_individual = individual[:]
        for i in range(len(mutated_individual)):
            if random.random() < 0.1:  # Mutation probability of 10%
                mutated_individual[i] = random.randint(0, 7)  # Randomly change the position of a queen
        return mutated_individual

    def visualize(self, individual):
        board = [['.'] * 8 for _ in range(8)]
        for col, row in enumerate(individual):
            board[row][col] = 'Q'
        board_str = '\n'.join([' '.join(row) for row in board])
        return board_str

    def run(self, iterations=100):
        best_individual = None
        best_fitness = 0
        for i in range(iterations):
            print(f"Iteration {i + 1}:")
            selected_individuals = self.selection()
            current_best_individual = selected_individuals[0]
            current_best_fitness = self.fitness(current_best_individual)
            if current_best_fitness > best_fitness:
                best_individual = current_best_individual
                best_fitness = current_best_fitness
            print("Best Individual:", current_best_individual, "Fitness:", current_best_fitness)
            new_population = []
            for _ in range(self.population_size // 2):
                parent1, parent2 = random.sample(selected_individuals, 2)
                child1, child2 = self.crossover(parent1, parent2)
                new_population.extend([self.mutation(child1), self.mutation(child2)])
            self.population = new_population
        return best_individual, best_fitness, self.visualize(best_individual)

# Example usage:
eight_queens_ga = EightQueensGA()
best_individual, best_fitness, best_visualization = eight_queens_ga.run()

print("\nBest Individual Found:")
print(best_individual)
print("Fitness:", best_fitness)
print("Visualization:\n", best_visualization)
 