class EightQueens:
    def __init__(self, initial_state=None, transition_model='basic'):
        self.size = 8
        self.initial_state = initial_state if initial_state else self.random_initial_state()
        self.transition_model = transition_model

    def random_initial_state(self):
        # Generates a random initial state with one queen per column
        import random
        return [random.randint(0, self.size - 1) for _ in range(self.size)]

    def actions(self, state):
        # Generates all possible actions for the queens
        actions = []
        for col in range(self.size):
            current_row = state[col]
            for row in range(self.size):
                if row != current_row:
                    actions.append((col, row))
        return actions

    def transition(self, state, action):
        # Returns the new state after applying the action
        col, row = action
        new_state = list(state)
        new_state[col] = row
        return new_state

    def heuristic(self, state):
        # Heuristic: number of pairs of queens that are attacking each other
        conflicts = 0
        for i in range(self.size):
            for j in range(i + 1, self.size):
                if state[i] == state[j] or abs(state[i] - state[j]) == abs(i - j):
                    conflicts += 1
        return conflicts

    def cost(self, state1, state2):
        # Uniform cost for moving a queen
        return 1

    def is_goal(self, state):
        # Goal is achieved if there are no conflicts
        return self.heuristic(state) == 0

    def visualize(self, state):
        # Visualizes the board in ASCII
        board = [['.'] * self.size for _ in range(self.size)]
        for col, row in enumerate(state):
            board[row][col] = 'Q'
        board_str = '\n'.join([' '.join(row) for row in board])
        return board_str


# Example usage:
initial_state = [5, 0, 2, 6, 6, 3, 7, 4]
eight_queens = EightQueens(initial_state)

print("Initial State:")
print(eight_queens.visualize(eight_queens.initial_state))
print("Heuristic of Initial State:", eight_queens.heuristic(eight_queens.initial_state))
print("Is Initial State Goal?", eight_queens.is_goal(eight_queens.initial_state))

# Generate a new state by applying an action
new_state = eight_queens.transition(eight_queens.initial_state, (0, 1))
print("\nNew State after moving queen in column 0 to row 1:")
print(eight_queens.visualize(new_state))
print("Heuristic of New State:", eight_queens.heuristic(new_state))
print("Is New State Goal?", eight_queens.is_goal(new_state))
