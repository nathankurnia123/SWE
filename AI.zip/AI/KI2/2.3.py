class EightQueens:
    def __init__(self):
        self.size = 8
        self.solutions = []

    def solve(self):
        self.solutions = []
        self._backtrack([], 0)
        return self.solutions

    def _backtrack(self, state, col):
        if col == self.size:
            self.solutions.append(state[:])
            return

        for row in range(self.size):
            if self._is_valid(state, col, row):
                state.append(row)
                self._backtrack(state, col + 1)
                state.pop()

    def _is_valid(self, state, col, row):
        for c in range(col):
            r = state[c]
            if r == row or abs(r - row) == abs(c - col):
                return False
        return True

    def visualize(self, state):
        board = [['.'] * self.size for _ in range(self.size)]
        for col, row in enumerate(state):
            board[row][col] = 'Q'
        board_str = '\n'.join([' '.join(row) for row in board])
        return board_str

# Example usage:
eight_queens = EightQueens()
solutions = eight_queens.solve()

print(f"Total solutions: {len(solutions)}\n")
for index, solution in enumerate(solutions):
    print(f"Solution {index + 1}:")
    print(eight_queens.visualize(solution))
    print()
